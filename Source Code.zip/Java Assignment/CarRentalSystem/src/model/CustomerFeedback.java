/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author USER
 */
public class CustomerFeedback {
    private String feed1;
    private String feed2;
    private String feed3;
    private String feed4;
    private String feed5;
    private String comment;
    private String bookId;
    private String total;
    private String avgTotal;
    private String numPlate;

    public String getFeed1() {
        return feed1;
    }

    public void setFeed1(String feed1) {
        this.feed1 = feed1;
    }

    public String getFeed2() {
        return feed2;
    }

    public void setFeed2(String feed2) {
        this.feed2 = feed2;
    }

    public String getFeed3() {
        return feed3;
    }

    public void setFeed3(String feed3) {
        this.feed3 = feed3;
    }

    public String getFeed4() {
        return feed4;
    }

    public void setFeed4(String feed4) {
        this.feed4 = feed4;
    }

    public String getFeed5() {
        return feed5;
    }

    public void setFeed5(String feed5) {
        this.feed5 = feed5;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public String getBookId() {
        return bookId;
    }

    public void setBookId(String bookId) {
        this.bookId = bookId;
    }

    public String getTotal() {
        return total;
    }

    public void setTotal(String total) {
        this.total = total;
    }

    public String getAvgTotal() {
        return avgTotal;
    }

    public void setAvgTotal(String avgTotal) {
        this.avgTotal = avgTotal;
    }

    public String getNumPlate() {
        return numPlate;
    }

    public void setNumPlate(String numPlate) {
        this.numPlate = numPlate;
    }



}
