package data;

import java.io.*;
import javax.swing.JOptionPane;
import model.*;

public class StoreData {

    public static void CustomerRegistration(User user) {
        try {
            FileWriter fw = new FileWriter("user.txt", true);
            BufferedWriter bw = new BufferedWriter(fw);
            PrintWriter pw;
            pw = new PrintWriter(bw);
            pw.println("CUSTOMER//" + user.getName() + "//" + user.getUsername() + "//" + user.getIc() + "//" 
                    + user.getPhone() + "//" + user.getEmail() + "//" + user.getPassword() + "//CUSTOMER");
            pw.close();
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }

    public static void AdminRegistration(User user, String status) {
        try {
            FileWriter fw = new FileWriter("user.txt", true);
            BufferedWriter bw = new BufferedWriter(fw);
            PrintWriter pw;
            pw = new PrintWriter(bw);
            pw.println("ADMIN//-//" + user.getUsername() + "//-//-//-//" + user.getPassword() + "//" + status);
            pw.close();
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }

    public static void CarRegistration(Car car) {
        try {
            FileWriter fw = new FileWriter("car.txt", true);
            BufferedWriter bw = new BufferedWriter(fw);
            PrintWriter pw;
            pw = new PrintWriter(bw);
            pw.println(car.getNumberPlate() + "//" + car.getBrand() + "//" + car.getModel() + "//-//" + car.getLocation() + "//" + car.getDailyRate() + "//" + car.getTransmission() + "//" + car.getNumberOfPax() + "//AVAILABLE");
            pw.close();
            JOptionPane.showMessageDialog(null, "Congratulations! " + car.getNumberPlate() + " is added into the car database.", "Car Added Successfully!", JOptionPane.INFORMATION_MESSAGE);
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }

    public static void UserLoginRecord(String loginDateTime, User user, String userType) {
        try {
            FileWriter fw = new FileWriter("loginRecord.txt", true);
            BufferedWriter bw = new BufferedWriter(fw);
            PrintWriter pw;
            pw = new PrintWriter(bw);
            pw.println(userType + "//" + user.getUsername() + "//" + loginDateTime + "//");
            pw.close();
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }

    public static void storeBooking(Booking booking) {
        try {
            //read file
            File file = new File("booking.txt");
            InputStreamReader streamReader = new InputStreamReader(new FileInputStream(file));
            BufferedReader br = new BufferedReader(streamReader);

            //read line by line
            String line = new String();
            while (br.ready()) {
                line = br.readLine();
            }

            //after loop take the last line
            //split the user info
            String[] details = line.split("//");
            int num = Integer.parseInt(details[0]);

            //create new id
            int id = num + 1;

            //to String
            String newId = Integer.toString(id);

            FileWriter fw = new FileWriter("booking.txt", true);
            BufferedWriter bw = new BufferedWriter(fw);
            PrintWriter pw;
            pw = new PrintWriter(bw);
            pw.println(newId + "//"
                    + booking.getIc() + "//"
                    + booking.getName() + "//"
                    + booking.getEmail() + "//"
                    + booking.getContact() + "//"
                    + booking.getNationality() + "//"
                    + booking.getNumberPlate() + "//"
                    + booking.getCarBrand() + "//"
                    + booking.getModel() + "//"
                    + booking.getPickupLocation() + "//"
                    + booking.getReturnLocation() + "//"
                    + booking.getPickUpDate() + "//"
                    + booking.getReturnDate() + "//"
                    + "-" + "//"
                    + booking.getPickUpTime() + "//"
                    + booking.getReturnTime() + "//"
                    + booking.getRentpurpose() + "//"
                    + booking.getRemarks() + "//"
                    + booking.getPaymentMethod() + "//"
                    + booking.getPaymentStatus() + "//"
                    + booking.getStatus() + "//"
                    + booking.getRentalFee() + "//"
                    + booking.getPayUponCollection() + "//"
                    + booking.getPayOnline() + "//"
                    + "-" + "//"
                    + "-" + "//"
                    + "-");

            pw.close();
            JOptionPane.showMessageDialog(null, "Your booking is registered successfully!\nPlease wait for you booking to be approved.", "Congratulations!", JOptionPane.OK_OPTION);

        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }

}
