
package data;

import java.io.IOException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import model.Car;

public class ValidateCar {

    public static Boolean ExistingCar(Car car) {
        //set as false in default
        Boolean carExist = false;

        //get number plate
        String numberPlate = car.getNumberPlate();

        try {
            String[] carInfo = RetrieveData.RetrieveData("car.txt");

            //create arraylist to store all existing Number Plate
            ArrayList<String> existingNumberPlate;
            existingNumberPlate = new ArrayList<>();

            //loop to get each car from carInfo arraylist
            for (String eachCar : carInfo) {

                //split the car info
                String[] carDetails = eachCar.split("//");

                //add all car number plate to arraylist
                existingNumberPlate.add(carDetails[0]);
            }

            //loop the existing number plate arraylist to check if car exist
            for (int i = 0; i < existingNumberPlate.size(); i++) {
                if (numberPlate.equalsIgnoreCase(existingNumberPlate.get(i))) {
                    carExist = true;
                    break;
                }
            }

        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, e);
        }

        return carExist;

    }

}
