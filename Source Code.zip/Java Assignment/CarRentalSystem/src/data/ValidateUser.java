package data;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import model.User;

public class ValidateUser {

    public static Boolean ExistingCustomer(User user) {
        //set as false in default
        Boolean accountExist = false;

        //get ic
        String ic = user.getIc();

        //get username
        String username = user.getUsername();

        try {
            String[] userInfo = RetrieveData.RetrieveData("user.txt");

            //create arraylist to store all ic
            ArrayList<String> existingIC;
            existingIC = new ArrayList<>();

            //create arraylist to store all username
            ArrayList<String> existingUsername;
            existingUsername = new ArrayList<>();

            //loop to get each user from userInfo arraylist
            for (String eachUser : userInfo) {

                //split the user info
                String[] userDetails = eachUser.split("//");

                //add all ic to arraylist
                existingIC.add(userDetails[3]);

                //add all username to arraylist
                existingUsername.add(userDetails[2]);
            }

            //loop the existingIC arraylist to check if account exists
            for (int i = 0; i < existingIC.size(); i++) {
                if (username.equalsIgnoreCase(existingUsername.get(i)) || ic.equalsIgnoreCase(existingIC.get(i))) {
                    accountExist = true;
                    break;
                }
            }

        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, e);
        }

        return accountExist;

    }

    public static Boolean ExistingAdmin(User user) {
        //set as false in default
        Boolean usernameExist = false;

        //get username
        String username = user.getUsername();

        try {
            String[] userInfo = RetrieveData.RetrieveData("user.txt");

            //create arraylist to store all username
            ArrayList<String> existingUsername;
            existingUsername = new ArrayList<>();

            //loop to get each user from userInfo arraylist
            for (String eachUser : userInfo) {

                //split the user info
                String[] userDetails = eachUser.split("//");

                //add all username to arraylist
                existingUsername.add(userDetails[2]);
            }

            //loop the existingUsername arraylist to check if account exists
            for (int i = 0; i < existingUsername.size(); i++) {
                if (username.equalsIgnoreCase(existingUsername.get(i))) {
                    usernameExist = true;
                    break;
                }
            }

        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, e);
        }

        return usernameExist;

    }

    public static Boolean CustomerLoginCredential(User user) {

        //set as false in default
        Boolean credentialCorrect = false;

        //get username
        String username = user.getUsername();

        //get password
        String password = user.getPassword();

        try {
            String[] userInfo = RetrieveData.RetrieveData("user.txt");

            //create arraylist to store all usernames
            ArrayList<String> existingUsername
                    = new ArrayList<>();

            //create arraylist to store all passwords
            ArrayList<String> existingPassword
                    = new ArrayList<>();

            //loop to get each user from userInfo arraylist
            for (String eachUser : userInfo) {

                //split the user info
                String[] userDetails = eachUser.split("//");

                //add all username to arraylist
                existingUsername.add(userDetails[2]);

                //add all password to arraylist
                existingPassword.add(userDetails[6]);
            }

            //loop the existing Username and password  arraylist to check credential
            for (int i = 0; i < existingUsername.size(); i++) {
                if (username.equals(existingUsername.get(i)) && password.equals(existingPassword.get(i))) {
                    credentialCorrect = true;
                    break;
                }
            }

        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, e);
        }

        return credentialCorrect;

    }

    public static Boolean AdminLoginCredential(User user) {

        //set as false in default
        Boolean credentialCorrect = false;

        //get username and password
        String username = user.getUsername();
        String password = user.getPassword();

        try {
            String[] userInfo = RetrieveData.RetrieveData("user.txt");

            //create arraylist to store all usernames
            ArrayList<String> existingUsername
                    = new ArrayList<>();

            //create arraylist to store all passwords
            ArrayList<String> existingPassword
                    = new ArrayList<>();

            //create arraylist to store all account status
            ArrayList<String> existingAccountStatus
                    = new ArrayList<>();

            //loop to get each user from userInfo arraylist
            for (String eachUser : userInfo) {

                //split the user info
                String[] userDetails = eachUser.split("//");

                //add all username to arraylist
                existingUsername.add(userDetails[2]);

                //add all password to arraylist
                existingPassword.add(userDetails[6]);

                //add all account to arraylist
                existingAccountStatus.add(userDetails[7]);
            }

            //loop the existing Username and password  arraylist to check credential
            for (int i = 0; i < existingUsername.size(); i++) {
                if (username.equals(existingUsername.get(i)) && password.equals(existingPassword.get(i)) && existingAccountStatus.get(i).equalsIgnoreCase("APPROVED")) {
                    credentialCorrect = true;
                    break;
                } else if (username.equals(existingUsername.get(i)) && password.equals(existingPassword.get(i)) && existingAccountStatus.get(i).equalsIgnoreCase("DEFAULT ADMIN")) {
                    credentialCorrect = true;
                    break;
                }
            }

        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, e);
        }

        return credentialCorrect;

    }

    public static Boolean ExistingUsername(User user) {
        //set as false in default
        Boolean usernameExist = false;

        //get username
        String username = user.getUsername();

        //set username appear num of times
        int num = 0;

        try {
            String[] userInfo = RetrieveData.RetrieveData("user.txt");

            //create arraylist to store all username
            ArrayList<String> existingUsername;
            existingUsername = new ArrayList<>();

            //loop to get each user from userInfo arraylist
            for (String eachUser : userInfo) {

                //split the user info
                String[] userDetails = eachUser.split("//");

                //add all username to arraylist
                existingUsername.add(userDetails[2]);
            }

            //loop the existingIC arraylist to check if account exists
            for (int i = 0; i < existingUsername.size(); i++) {
                if (username.equalsIgnoreCase(existingUsername.get(i))) {
                    num++;
                    break;
                }
            }

            //if more than 1 user has this username
            if (num > 1) {
                usernameExist = true;
            }

        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, e);
        }

        return usernameExist;

    }

    public static String[] SearchUser(String searchValue, String userType) throws FileNotFoundException {

        String[] userInfo = RetrieveData.RetrieveData("user.txt");

        //create arraylist to store all updated user
        ArrayList<String> userList
                = new ArrayList<>();

        //loop to get each user from user info arraylist
        for (String eachUser : userInfo) {

            //split the user info
            String[] userData = eachUser.split("//");

            //avoid redundant data
            Boolean store = false;

            //if user is admin
            if (userData[0].equalsIgnoreCase(userType)) {

                //get details of one user
                for (String detail : userData) {

                    detail = detail.toLowerCase().strip();
                    searchValue = searchValue.toLowerCase().strip();

                    if (detail.contains(searchValue) && !store || searchValue.isEmpty() && !store) {
                        //set true to stop adding
                        store = true;

                        //add each user to list
                        userList.add(eachUser);

                    }

                }

            }

        }

        // convert user list to string array
        String[] userDetails
                = userList.toArray(String[]::new);

        return userDetails;
    }

}
