package data;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import model.*;

public class ModifyCarData {

    public static String[] UpdateCarInfo(Car car) throws FileNotFoundException {

        //get number plate
        String carNumberPlate = car.getNumberPlate().toLowerCase().strip();

        // modifiedlist to store all updated cars
        ArrayList<String> updatedCarInfo
                = new ArrayList<>();

        String[] carInfo = RetrieveData.RetrieveData("car.txt");

        //loop to get each car from arraylist
        for (String eachCar : carInfo) {

            //split the car info
            String[] carData = eachCar.split("//");

            //store car info
            if (carNumberPlate.equals(carData[0].toLowerCase().strip())) {
                carData[1] = car.getBrand();
                carData[2] = car.getModel();
                carData[4] = car.getLocation();
                carData[6] = car.getTransmission();
                carData[7] = car.getNumberOfPax();
                carData[5] = car.getDailyRate();

                StringBuilder carBd = new StringBuilder();
                for (int i = 0; i < carData.length; i++) {

                    carBd.append(carData[i]);

                    //last element no need seperator
                    if (i == (carData.length - 1)) {
                        break;
                    }
                    carBd.append("//");
                }

                String carDetails = carBd.toString();
                updatedCarInfo.add(carDetails);
            }

            updatedCarInfo.add(eachCar);

        }

        // convert car List to string array
        String[] modifiedCars
                = updatedCarInfo.toArray(String[]::new);

        return modifiedCars;
    }

    public static String[] DeleteCar(Car car) throws FileNotFoundException {

        //get number plate
        String carNumberPlate = car.getNumberPlate().toLowerCase().strip();

        // modifiedlist to store all updated cars
        ArrayList<String> updatedCarInfo
                = new ArrayList<>();

        String[] carInfo = RetrieveData.RetrieveData("car.txt");

        //loop to get each booking from booking details arraylist
        for (String eachCar : carInfo) {

            //split the car info
            String[] carData = eachCar.split("//");

            //store booking info of that room
            if (carNumberPlate.equals(carData[0] = carData[0].toLowerCase().strip())) {

                //continue without saving info
            } else {

                updatedCarInfo.add(eachCar);
            }

        }

        // convert booking List to string array
        String[] modifiedCars
                = updatedCarInfo.toArray(String[]::new);

        return modifiedCars;
    }

    public static String[] ChangeCarStatus(Car car, String previousStatus, String futureStatus) throws FileNotFoundException {

        //get number plate
        String carNumberPlate = car.getNumberPlate();

        //get file info
        String[] carInfo = RetrieveData.RetrieveData("car.txt");

        // modifiedlist to store all updated cars
        ArrayList<String> updatedCarInfo
                = new ArrayList<>();

        //loop to get each car from car info arraylist
        for (String eachCar : carInfo) {

            //split the car info
            String[] carData = eachCar.split("//");

            if (carNumberPlate.equalsIgnoreCase(carData[0])) {

                if (previousStatus.contains(carData[8]) && !carData[8].equalsIgnoreCase("RENTED")) {

                    carData[8] = futureStatus;
                    JOptionPane.showMessageDialog(null, "Status Successfully Updated!\nStatus: " + futureStatus, "Congratulations!", JOptionPane.INFORMATION_MESSAGE);

                } else if (carData[8].equalsIgnoreCase("RENTED")) {

                    if (futureStatus.equalsIgnoreCase("BLOCKED") || futureStatus.equalsIgnoreCase("AVAILABLE")) {

                        JOptionPane.showMessageDialog(null, "Unable to change car status!\nThis car is rented out!\nCar Status: RENTED", "Error!", JOptionPane.WARNING_MESSAGE);

                    } else if (futureStatus.equalsIgnoreCase("RETURN")) {

                        carData[8] = "AVAILABLE";
                        JOptionPane.showMessageDialog(null, "Car Successfully Returned!\nStatus: AVAILABLE", "Congratulations!", JOptionPane.INFORMATION_MESSAGE);

                    }

                } else if (futureStatus.equalsIgnoreCase("BLOCKED") && carData[8].equalsIgnoreCase("BLOCKED")) {

                    JOptionPane.showMessageDialog(null, "Unable to change car status!\nThis car is already blocked!\nCar Status: BLOCKED", "Error!", JOptionPane.WARNING_MESSAGE);

                } else if (futureStatus.equalsIgnoreCase("AVAILABLE") && carData[8].equalsIgnoreCase("AVAILABLE")) {

                    JOptionPane.showMessageDialog(null, "Unable to change car status!\nThis car is already unblocked!\nCar Status: AVAILABLE", "Error!", JOptionPane.WARNING_MESSAGE);

                }
            }

            StringBuilder carBd = new StringBuilder();
            for (int i = 0; i < carData.length; i++) {

                carBd.append(carData[i]);

                //last element no need seperator
                if (i == (carData.length - 1)) {
                    break;
                }
                carBd.append("//");
            }

            String carDetails = carBd.toString();

            updatedCarInfo.add(carDetails);
        }

        // convert car List to string array
        String[] modifiedCars
                = updatedCarInfo.toArray(String[]::new);

        return modifiedCars;
    }

    public static String[] UpdateCarRate(CustomerFeedback feed) throws FileNotFoundException {

        //get number plate
        String carNumberPlate = feed.getNumPlate().toLowerCase().strip();

        // modifiedlist to store all updated cars
        ArrayList<String> updatedCarInfo
                = new ArrayList<>();

        String[] carInfo = RetrieveData.RetrieveData("car.txt");

        //loop to get each car from arraylist
        for (String eachCar : carInfo) {

            //split the car info
            String[] carData = eachCar.split("//");
            if (carData[3].equals("-")) {
                String oriRate = "0";
                //convert string to int

                int oriNum = Integer.parseInt(oriRate);

                String newRate = feed.getAvgTotal();
                int newNum = Integer.parseInt(newRate);

                //calculate
                int ori = newNum * 5;
                int newTotalRate = oriNum + ori;
                int newAvgRate = newTotalRate / 5;

                //convert to string
                String newRating = Integer.toString(newAvgRate);

                //store car info
                if (carNumberPlate.equals(carData[0].toLowerCase().strip())) {

                    carData[3] = newRating;
                }

                StringBuilder carBd = new StringBuilder();
                for (int i = 0; i < carData.length; i++) {

                    carBd.append(carData[i]);

                    //last element no need seperator
                    if (i == (carData.length - 1)) {
                        break;
                    }
                    carBd.append("//");
                }

                String carDetails = carBd.toString();

                updatedCarInfo.add(carDetails);

            } else {
                String oriRate = carData[3];
                //convert string to int

                int oriNum = Integer.parseInt(oriRate);

                String newRate = feed.getAvgTotal();
                int newNum = Integer.parseInt(newRate);

                //calculate
                int ori = newNum * 5;
                int newTotalRate = oriNum + ori;
                int newAvgRate = newTotalRate / 5;

                //convert to string
                String newRating = Integer.toString(newAvgRate);
                System.out.println(newRating);

                //store car info
                if (carNumberPlate.equals(carData[0].toLowerCase().strip())) {

                    carData[3] = newRating;
                }

                StringBuilder carBd = new StringBuilder();
                for (int i = 0; i < carData.length; i++) {

                    carBd.append(carData[i]);

                    //last element no need seperator
                    if (i == (carData.length - 1)) {
                        break;
                    }
                    carBd.append("//");
                }

                String carDetails = carBd.toString();

                updatedCarInfo.add(carDetails);
            }

        }

        // convert car List to string array
        String[] modifiedCars
                = updatedCarInfo.toArray(String[]::new);

        return modifiedCars;
    }

    public static String[] UpdateCarLocation(Booking book) throws FileNotFoundException {

        //get number plate
        String carNumberPlate = book.getNumberPlate();
        String location = book.getReturnLocation();

        // modifiedlist to store all updated cars
        ArrayList<String> updatedCarInfo
                = new ArrayList<>();

        String[] carInfo = RetrieveData.RetrieveData("car.txt");

        //loop to get each car from arraylist
        for (String eachCar : carInfo) {

            //split the car info
            String[] carData = eachCar.split("//");

            //store car info
            if (carNumberPlate.equals(carData[0].toLowerCase().strip())) {
                carData[4] = location;

                StringBuilder carBd = new StringBuilder();
                for (int i = 0; i < carData.length; i++) {

                    carBd.append(carData[i]);

                    //last element no need seperator
                    if (i == (carData.length - 1)) {
                        break;
                    }
                    carBd.append("//");
                }

                String carDetails = carBd.toString();

                updatedCarInfo.add(carDetails);
            }

            updatedCarInfo.add(eachCar);
        }

        // convert car List to string array
        String[] modifiedCars
                = updatedCarInfo.toArray(String[]::new);

        return modifiedCars;
    }

}
