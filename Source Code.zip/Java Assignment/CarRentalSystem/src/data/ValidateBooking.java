package data;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.*;
import java.util.*;
import javax.swing.JOptionPane;
import model.Booking;

public class ValidateBooking {

    public static String CalcFine(long milliesDiff, String dailyRate) {

        //convert to long
        long price = Long.parseLong(dailyRate) * 2;

        //calc fines by 3 times of normal price
        long min = ((milliesDiff / (1000 * 60)) % 60) * (price / 24 / 60);
        long hr = ((milliesDiff / (1000 * 60 * 60)) % 24) * (price / 24);
        long yr = (milliesDiff / (1000l * 60 * 60 * 24 * 365)) * (price * 365);
        long day = (milliesDiff / (1000l * 60 * 60 * 24) % 365) * price;

        //2 decimal place
        NumberFormat nf = NumberFormat.getInstance();
        nf.setMaximumFractionDigits(2);

        String fine = nf.format(min + hr + yr + day - price); //deduct 24 hr

        return fine;
    }

    public static Boolean ExistingBooking(String id) {
        //set as false in default
        Boolean bookingExist = false;

        //get id
        String bookingId = id;

        try {
            String[] bookingInfo = RetrieveData.RetrieveData("booking.txt");

            //create arraylist to store all ic
            ArrayList<String> existingId;
            existingId = new ArrayList<>();

            //loop to get each booking from bookingInfo arraylist
            for (String eachBooking : bookingInfo) {

                //split the booking info
                String[] bookingDetails = eachBooking.split("//");

                //add all id to arraylist
                existingId.add(bookingDetails[0]);

            }

            //loop the existingId arraylist to check if abooking exists
            for (int i = 0; i < existingId.size(); i++) {
                if (bookingId.equalsIgnoreCase(existingId.get(i))) {
                    bookingExist = true;
                    break;
                }
            }

        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, e);
        }

        return bookingExist;

    }

    public static Boolean CarAvailability(Booking book) throws FileNotFoundException, ParseException {

        String getPickUpDate = book.getPickUpDate();
        String getPickUpTime = book.getPickUpTime();
        String getReturnDate = book.getReturnDate();
        String getReturnTime = book.getReturnTime();

        String numPlate = book.getNumberPlate();

        //converts string to date with the format
        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy HH:mm");

        //get pickup datetime + return datetime
        Date inPickup = sdf.parse(getPickUpDate + " " + getPickUpTime);
        Date inReturn = sdf.parse(getReturnDate + " " + getReturnTime);

        String[] bookingInfo = RetrieveData.RetrieveData("booking.txt");
        String[] carInfo = RetrieveData.RetrieveData("car.txt");

        //store num plate in booking file
        ArrayList<String> bookingNumPlate
                = new ArrayList<>();

        //store num plate in car file
        ArrayList<String> carNumPlate
                = new ArrayList<>();

        //store booking pickup date time
        ArrayList<Date> bookingPickup
                = new ArrayList<>();

        //store booking return date time
        ArrayList<Date> bookingReturn
                = new ArrayList<>();

        //loop to get each numberplate from booking arraylist
        for (String eachBooking : bookingInfo) {

            //split the car info
            String[] bookingDetails = eachBooking.split("//");

            //add all booking number plate to arraylist
            bookingNumPlate.add(bookingDetails[6]);

            //converts string to date with the format
            //loop to get booking pickup date time and return date time
            Date pickup = sdf.parse(bookingDetails[11] + " " + bookingDetails[14]);
            Date ret = sdf.parse(bookingDetails[12] + " " + bookingDetails[15]);

            //increment 1 days for return car
            Calendar c = Calendar.getInstance();
            c.setTime(ret);
            c.add(Calendar.DAY_OF_MONTH, 1);
            String retu = sdf.format(c.getTime());
            Date retur = sdf.parse(retu);

            //store pickup date time and return date time
            bookingPickup.add(pickup);
            bookingReturn.add(retur);

        }

        //loop to get each car from carInfo arraylist
        for (String eachCar : carInfo) {

            //split the car info
            String[] carDetails = eachCar.split("//");

            //add all car number plate to arraylist
            carNumPlate.add(carDetails[0]);
        }

        Boolean available = true;

        //loop the booking number plate arraylist to check if car exist
        for (int i = 0; i < bookingNumPlate.size(); i++) {

            //remove numberplate from car list if not booked
            if (bookingNumPlate.get(i).equalsIgnoreCase(numPlate)) {

                //remove car from car list if input pickup datetime and return datetime is within the booking datetime
                if (inPickup.after(bookingPickup.get(i)) && inPickup.before(bookingReturn.get(i))) {

                    available = false;

                } else if (inReturn.after(bookingPickup.get(i)) && inReturn.before(bookingReturn.get(i))) {

                    available = false;

                } else if (inPickup.equals(bookingPickup.get(i)) || inPickup.equals(bookingReturn.get(i))) {

                    available = false;
                } else if (inReturn.equals(bookingPickup.get(i)) || inReturn.equals(bookingReturn.get(i))) {

                    available = false;
                }

            }
        }

        return available;

    }

    public static String[] getAllCarDetails(String[] getCars, String location) throws FileNotFoundException {

        String[] carInfo = RetrieveData.RetrieveData("car.txt");

        //create arraylist to store all car number plate
        ArrayList<String> carList
                = new ArrayList<>();

        //loop to get each car from car info arraylist
        for (String eachCar : carInfo) {

            //split the car info
            String[] carData = eachCar.split("//");

            //avoid redundant data
            Boolean store = false;

            //get details of one booking
            for (String car : getCars) {

                if (car.equalsIgnoreCase(carData[0]) && location.equalsIgnoreCase(carData[4])&& !carData[8].equalsIgnoreCase("BLOCKED") && !store) {
                    //set true to stop adding
                    store = true;

                    //add each car to list
                    carList.add(eachCar);
                }

            }

        }

        // convert car list to string array
        String[] carDetails
                = carList.toArray(String[]::new);

        return carDetails;
    }

    public static String[] FilterBooking(String filterTime) throws FileNotFoundException, ParseException {

        //converts string to date with the format
        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy HH:mm");

        String[] bookingInfo = RetrieveData.RetrieveData("booking.txt");

        //create arraylist to store all details
        ArrayList<String> bookingList
                = new ArrayList<>();

        //current
        Date now = new Date();
        String tdy = sdf.format(now);
        Date today = sdf.parse(tdy);

        //loop to get each record from bookingInfo arraylist
        for (String eachBooking : bookingInfo) {

            //split info
            String[] bookingDetails = eachBooking.split("//");

            //converts string to date with the format
            Date pickup = sdf.parse(bookingDetails[11] + " " + bookingDetails[14]);
            Date retur = sdf.parse(bookingDetails[12] + " " + bookingDetails[15]);

            if (filterTime.equalsIgnoreCase("NOW")) {

                //now
                if (today.after(pickup) && today.before(retur)) {
                    bookingList.add(eachBooking);
                } else if (today.equals(pickup) || today.equals(retur)) {
                    bookingList.add(eachBooking);
                }
            } else if (filterTime.equalsIgnoreCase("PAST")) {

                //past
                if (today.after(retur)) {
                    bookingList.add(eachBooking);
                }
            } else if (filterTime.equalsIgnoreCase("FUTURE")) {

                //future
                if (today.before(pickup)) {
                    bookingList.add(eachBooking);
                }
            }
        }

        // convert list to string array
        String[] bookingDetails
                = bookingList.toArray(String[]::new);

        return bookingDetails;

    }

   
    
}
