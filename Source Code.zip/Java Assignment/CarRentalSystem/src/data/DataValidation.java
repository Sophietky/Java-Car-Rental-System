package data;

import java.awt.HeadlessException;
import java.util.Date;
import javax.swing.JOptionPane;
import model.*;

public class DataValidation {

    //email format alphabets@email.com ((a-z0-9) + @ + (a-z0-9) + . + >=2(a-z0-9)
    public static String emailValidation = "^[a-z0-9._%+-]+[@]+[a-zA-Z0-9.-]+[.]+[a-zA-Z0-9]+$";

    //phone exactly 10 number allow only
    public static String phoneValidation = "^\\d{10}$";

    //alphanumeric value with special char 8 - 20
    public static String pwdValidation = "^[a-zA-Z0-9._%+-@#%&*]{8,20}+$";

    //alphanumeric value 8 - 20
    public static String usernameValidation = "^[a-zA-Z0-9]{8,20}+$";

    // exactly 12 number oni
    public static String icValidation = "^\\d{12}$";

    //number plate contain number and letters
    public static String numberPlateValidation = "^[a-zA-Z]*[0-9]+$";

    //price only contain numbers
    public static String dailyRateValidation = "^[0-9]*$";

    public static Boolean CustomerRegistration(User user) {
        Boolean valid = false;

        try {
            if (user.getName().equals("") || user.getUsername().equals("") || user.getIc().equals("") || user.getPhone().equals("") || user.getEmail().equals("") || user.getPassword().equals("") || user.getConfirmPassword().equals("")) {
                JOptionPane.showMessageDialog(null, "All fields are required!\n Please fill up all the details!", "Warning!", JOptionPane.WARNING_MESSAGE);
            } else if (!user.getIc().matches(icValidation)) {
                JOptionPane.showMessageDialog(null, "Your IC No./ Passport No. should be exactly 12 numbers.\nPlease enter a valid IC No./Passport No.", "Warning!", JOptionPane.WARNING_MESSAGE);
            } else if (!user.getEmail().matches(emailValidation)) {
                JOptionPane.showMessageDialog(null, "Your email is invalid.\nPlease enter a valid email.", "Warning!", JOptionPane.WARNING_MESSAGE);
            } else if (!user.getPhone().matches(phoneValidation)) {
                JOptionPane.showMessageDialog(null, "Your phone number is invalid.\nPlease a valid phone number.", "Warning!", JOptionPane.WARNING_MESSAGE);
            } else if (!user.getPassword().matches(pwdValidation)) {
                JOptionPane.showMessageDialog(null, "Your password should contain 8 to 20 characters.\nPlease enter again.", "Warning!", JOptionPane.WARNING_MESSAGE);
            } else if (!user.getPassword().equals(user.getConfirmPassword())) {
                JOptionPane.showMessageDialog(null, "Your password and confirm password do not match!\nPlease ensure you entered the correct password.", "Warning!", JOptionPane.WARNING_MESSAGE);
            } else {
                valid = true;
            }
        } catch (HeadlessException e) {
            JOptionPane.showMessageDialog(null, e);
        }

        return valid;
    }

    public static Boolean AdminRegistration(User user) {
        Boolean valid = false;

        try {
            if (user.getUsername().equals("") || user.getPassword().equals("") || user.getConfirmPassword().equals("")) {
                JOptionPane.showMessageDialog(null, "All fields are required!\n Please fill up all the details!", "Warning!", JOptionPane.WARNING_MESSAGE);
            } else if (!user.getPassword().matches(pwdValidation)) {
                JOptionPane.showMessageDialog(null, "Your password should contain 8 to 20 characters.\nPlease enter again.", "Warning!", JOptionPane.WARNING_MESSAGE);
            } else if (!user.getPassword().equals(user.getConfirmPassword())) {
                JOptionPane.showMessageDialog(null, "Your password and confirm password do not match!\nPlease ensure you entered the correct password.", "Warning!", JOptionPane.WARNING_MESSAGE);
            } else {
                valid = true;
            }
        } catch (HeadlessException e) {
            JOptionPane.showMessageDialog(null, e);
        }

        return valid;
    }

    public static Boolean Login(User user) {
        Boolean valid = false;

        try {
            if (user.getUsername().equals("") || user.getPassword().equals("")) {
                JOptionPane.showMessageDialog(null, "Please enter username and password to login", "Warning!", JOptionPane.WARNING_MESSAGE);
            } else if (!user.getPassword().matches(pwdValidation)) {
                JOptionPane.showMessageDialog(null, "Please enter a valid password to login", "Warning!", JOptionPane.WARNING_MESSAGE);
            } else {
                valid = true;
            }
        } catch (HeadlessException e) {
            JOptionPane.showMessageDialog(null, e);
        }

        return valid;
    }

    public static Boolean CarRegistration(Car car) {
        Boolean valid = false;

        try {
            if (car.getNumberPlate().equals("") || car.getBrand().equals("") || car.getModel().equals("") || car.getTransmission() == null || car.getLocation().equals("") || car.getDailyRate().equals("") || car.getNumberOfPax().equals("")) {
                JOptionPane.showMessageDialog(null, "All fields are required!\n Please fill up all the details!", "Warning!", JOptionPane.WARNING_MESSAGE);
            } else if (!car.getNumberPlate().matches(numberPlateValidation)) {
                JOptionPane.showMessageDialog(null, "Car Number Plate should contain letters and numbers.\nPlease enter a valid car number plate.", "Warning!", JOptionPane.WARNING_MESSAGE);
            } else if (!car.getDailyRate().matches(dailyRateValidation)) {
                JOptionPane.showMessageDialog(null, "Daily Rate should contain numbers only.\nPlease enter a valid daily rate.", "Warning!", JOptionPane.WARNING_MESSAGE);
            } else {
                valid = true;
            }
        } catch (HeadlessException e) {
            JOptionPane.showMessageDialog(null, e);
        }

        return valid;
    }

    public static Boolean DateValidation(Date pickupDate, Date returnDate, Date ytd, Date today, String time, Booking book) throws NumberFormatException {
        Boolean valid = false;

        //pickup time, hour, minute
        String puTime = book.getPickUpTime();
        int puHour = Integer.parseInt(puTime.substring(0, 2));
        int puMin = Integer.parseInt(puTime.substring(3));

        //current time
        int curHour = Integer.parseInt(time.substring(0, 2));
        int curMin = Integer.parseInt(time.substring(3));

        if (returnDate.before(pickupDate)) {

            JOptionPane.showMessageDialog(null, "Your Return date should be later than Pick-up date", "Warning!", JOptionPane.WARNING_MESSAGE);

        } else if (pickupDate.before(ytd) || pickupDate.equals(ytd) || returnDate.before(ytd) || returnDate.equals(ytd)) {

            JOptionPane.showMessageDialog(null, "Your Pick-up date should be later than yesterday", "Warning!", JOptionPane.WARNING_MESSAGE);

        } else if (pickupDate.after(ytd)) {

            if (pickupDate.equals(today)) {

                if (puHour < curHour) {

                    JOptionPane.showMessageDialog(null, "Your Pick-up Time should be later than current time", "Warning!", JOptionPane.WARNING_MESSAGE);

                } else if (puHour == curHour && puMin < curMin) {

                    JOptionPane.showMessageDialog(null, "Your Pick-up Time should be later than current time", "Warning!", JOptionPane.WARNING_MESSAGE);

                }
            } else {

                valid = true;
            }

        } else {

            valid = true;
        }

        return valid;
    }

    public static Boolean returnCarDate(Date pickUpDate, Date returnDate, Date returnCarDate, Date today, String returnCarTime, Booking book) throws NumberFormatException {
        Boolean valid = false;

        //return car time
        String rTime = returnCarTime;
        int rHour = Integer.parseInt(rTime.substring(0, 2));
        int rMin = Integer.parseInt(rTime.substring(3));

        //pickup time
        String pTime = book.getPickUpTime();
        int pHour = Integer.parseInt(pTime.substring(0, 2));
        int pMin = Integer.parseInt(pTime.substring(3));

        if (returnCarDate.equals(pickUpDate)) {

            //check if return car time earlier than pick up time
            if (rHour < pHour) {

                JOptionPane.showMessageDialog(null, "Please enter a valid date!", "Warning!", JOptionPane.WARNING_MESSAGE);

            } else if (rHour == pHour && rMin < pMin) {

                JOptionPane.showMessageDialog(null, "Please enter a valid date!", "Warning!", JOptionPane.WARNING_MESSAGE);

            } else {
                valid = true;
            }

        } else if (returnCarDate.after(pickUpDate)) {

            valid = true;

        } else {

            JOptionPane.showMessageDialog(null, "Please enter a valid date!", "Warning!", JOptionPane.WARNING_MESSAGE);

        }

        return valid;
    }

    public static Boolean BookingValidation(Booking book) {
        Boolean valid = false;

        if (book.getIc().equals("") || book.getName().equals("") || book.getEmail().equals("")
                || book.getContact().equals("") || book.getNationality().equals("") || book.getNumberPlate().equals("")
                || book.getCarBrand().equals("") || book.getModel().equals("") || book.getPickupLocation().equals("")
                || book.getReturnLocation().equals("") || book.getPickUpDate().equals("") || book.getReturnDate().equals("")
                || book.getPickUpTime().equals("") || book.getReturnTime().equals("") || book.getRentpurpose().equals("")
                || book.getRemarks().equals("") || book.getPaymentMethod().equals("") || book.getPaymentStatus().equals("")
                || book.getStatus().equals("") || book.getRentalFee().equals("") || book.getPayUponCollection().equals("")
                || book.getPayOnline().equals("")) {

            JOptionPane.showMessageDialog(null, "All fields are required!\n Please fill up all the details!", "Warning!", JOptionPane.WARNING_MESSAGE);

        } else if (!book.getIc().matches(icValidation)) {
            JOptionPane.showMessageDialog(null, "Your IC No./ Passport No. should be exactly 12 numbers.\nPlease enter a valid IC No./Passport No.", "Warning!", JOptionPane.WARNING_MESSAGE);

        } else if (!book.getEmail().matches(emailValidation)) {
            JOptionPane.showMessageDialog(null, "Your email is invalid.\nPlease enter a valid email.", "Warning!", JOptionPane.WARNING_MESSAGE);

        } else if (!book.getContact().matches(phoneValidation)) {
            JOptionPane.showMessageDialog(null, "Your phone number is invalid.\nPlease a valid phone number.", "Warning!", JOptionPane.WARNING_MESSAGE);

        }else{
            valid = true;
        }

        return valid;
    }

    public static Boolean UpdateBookingValidation(Booking book) {
        Boolean valid = false;

        if (book.getName().equals("") || book.getEmail().equals("")
                || book.getContact().equals("") || book.getNationality().equals("") || book.getPickupLocation().equals("")
                || book.getRemarks().equals("") || book.getRentpurpose().equals("") || book.getPaymentMethod().equals("") 
                || book.getReturnLocation().equals("") ){

            JOptionPane.showMessageDialog(null, "All fields are required!\n Please fill up all the details!", "Warning!", JOptionPane.WARNING_MESSAGE);

        } else if (!book.getEmail().matches(emailValidation)) {
            JOptionPane.showMessageDialog(null, "Your email is invalid.\nPlease enter a valid email.", "Warning!", JOptionPane.WARNING_MESSAGE);

        } else if (!book.getContact().matches(phoneValidation)) {
            JOptionPane.showMessageDialog(null, "Your phone number is invalid.\nPlease a valid phone number.", "Warning!", JOptionPane.WARNING_MESSAGE);

        }else{
            valid = true;
        }

        return valid;
    }    
    
}
