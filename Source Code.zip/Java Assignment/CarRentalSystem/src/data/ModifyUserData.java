package data;

import java.io.FileNotFoundException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import model.User;

public class ModifyUserData {

    public static String[] EditCustomerAccount(User user) throws FileNotFoundException {
        String ic = user.getIc();

        ArrayList<String> modifiedList
                = new ArrayList<>();

        String[] userDetails = RetrieveData.RetrieveData("user.txt");

        //loop to get each user from user details arraylist
        for (String eachUser : userDetails) {

            //split the user info
            String[] userData = eachUser.split("//");

            //store user info
            if (ic.equals(userData[3]) && userData[0].equals("CUSTOMER")) {
                userData[1] = user.getName();
                userData[2] = user.getUsername();
                userData[3] = user.getIc();
                userData[4] = user.getPhone();
                userData[5] = user.getEmail();
                userData[6] = user.getPassword();

                StringBuilder userBd = new StringBuilder();
                for (int i = 0; i < userData.length; i++) {

                    userBd.append(userData[i]);

                    //last element no need seperator
                    if (i == (userData.length - 1)) {
                        break;
                    }
                    userBd.append("//");
                }

                String profile = userBd.toString();

                modifiedList.add(profile);
            }

            modifiedList.add(eachUser);
        }

        // convert user List to string array
        String[] modifiedProfile
                = modifiedList.toArray(String[]::new);

        return modifiedProfile;
    }

    public static String[] ChangeAdminStatus(User user, String futureStatus) throws FileNotFoundException {

        //get username
        String adminName = user.getUsername();

        //get file info
        String[] adminInfo = RetrieveData.RetrieveData("user.txt");

        // modifiedlist to store all updated admin info
        ArrayList<String> updatedAdminInfo
                = new ArrayList<>();

        //loop to get each admin from admin info arraylist
        for (String eachadmin : adminInfo) {

            //split the admin info
            String[] adminData = eachadmin.split("//");

            if (adminData[2].equalsIgnoreCase(adminName)) {

                if (adminData[7].equalsIgnoreCase("DEFAULT ADMIN")) {

                    //dont allow default admin change status
                    JOptionPane.showMessageDialog(null, "Unable to change the Default admin account status!\nStatus: DEFAULT ADMIN", "Error!", JOptionPane.WARNING_MESSAGE);

                }

                if (futureStatus.equalsIgnoreCase("APPROVED")) {

                    if (adminData[7].equalsIgnoreCase("APPROVED")) {

                        //already approved but want to approve again
                        JOptionPane.showMessageDialog(null, "Unable to change the admin account status!\nThis admin account is already APPROVED!\nAdmin Status: APPROVED", "Error!", JOptionPane.WARNING_MESSAGE);

                    } else if (!adminData[7].equalsIgnoreCase("DEFAULT ADMIN")) {

                        adminData[7] = "APPROVED";
                        JOptionPane.showMessageDialog(null, "Status Successfully Updated!\nStatus: APPROVED", "Congratulations!", JOptionPane.INFORMATION_MESSAGE);

                    }
                }

                if (futureStatus.equalsIgnoreCase("REJECTED")) {

                    if (adminData[7].equalsIgnoreCase("REJECTED")) {
                        //already rejected but want to reject again
                        JOptionPane.showMessageDialog(null, "Unable to change the admin account status!\nThis admin account is already REJECTED!\nAdmin Status: REJECTED", "Error!", JOptionPane.WARNING_MESSAGE);

                    } else if (!adminData[7].equalsIgnoreCase("DEFAULT ADMIN")) {

                        adminData[7] = "REJECTED";
                        JOptionPane.showMessageDialog(null, "Status Successfully Updated!\nStatus: REJECTED", "Congratulations!", JOptionPane.INFORMATION_MESSAGE);

                    }
                }

            }

            StringBuilder adminBd = new StringBuilder();
            for (int i = 0; i < adminData.length; i++) {

                adminBd.append(adminData[i]);

                //last element no need seperator
                if (i == (adminData.length - 1)) {
                    break;
                }
                adminBd.append("//");
            }

            String adminDetails = adminBd.toString();

            updatedAdminInfo.add(adminDetails);
        }

        // convert admin info array list to string array
        String[] modifiedadmins
                = updatedAdminInfo.toArray(String[]::new);

        return modifiedadmins;
    }

    public static String[] DeleteUser(User user) throws FileNotFoundException {

        //get username
        String username = user.getUsername();

        // modifiedlist to store all updated users
        ArrayList<String> updatedUserInfo
                = new ArrayList<>();

        String[] userInfo = RetrieveData.RetrieveData("user.txt");

        //loop to get each user from user info 
        for (String eachUser : userInfo) {

            //split the user info
            String[] userData = eachUser.split("//");

            //store user info 
            if (username.equalsIgnoreCase(userData[2])) {

                if (!userData[7].equalsIgnoreCase("DEFAULT ADMIN")) {

                    //continue without saving info
                    JOptionPane.showMessageDialog(null, "Account Successfully Deleted!", "Congratulations!", JOptionPane.INFORMATION_MESSAGE);

                } else {

                    JOptionPane.showMessageDialog(null, "Unable to delete this account !\nThis is DEFAULT ADMIN account!", "Error!", JOptionPane.WARNING_MESSAGE);

                    //store user info
                    updatedUserInfo.add(eachUser);
                }
            } else {

                //store user info
                updatedUserInfo.add(eachUser);
            }

        }

        // convert booking List to string array
        String[] modifiedCars
                = updatedUserInfo.toArray(String[]::new);

        return modifiedCars;
    }

    public static String[] LogoutRecord() throws FileNotFoundException {

        //get current date and time
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");
        LocalDateTime now = LocalDateTime.now();
        String logoutDateTime = dtf.format(now);

        // modifiedlist to store all updated login info
        ArrayList<String> updatedLoginInfo
                = new ArrayList<>();

        String[] loginInfo = RetrieveData.RetrieveData("loginRecord.txt");

        int num = 0;
        //loop to get each record from login info arraylist
        for (String eachRecord : loginInfo) {

            //split the booking info
            String[] data = eachRecord.split("//");

            //store booking info of that room
            if (num == (loginInfo.length - 1)) {
                data[2] = data[2] + "//" + logoutDateTime;

                StringBuilder recordBd = new StringBuilder();
                for (int i = 0; i < data.length; i++) {

                    recordBd.append(data[i]);

                    //last element no need seperator
                    if (i == (data.length - 1)) {
                        break;
                    }
                    recordBd.append("//");
                }

                String record = recordBd.toString();

                updatedLoginInfo.add(record);
            }

            updatedLoginInfo.add(eachRecord);

            num++;
        }

        // convert booking List to string array
        String[] modifiedInfo
                = updatedLoginInfo.toArray(String[]::new);

        return modifiedInfo;
    }
}
