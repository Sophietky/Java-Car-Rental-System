package data;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import model.Booking;

public class Formatting {

    String pickupDate, returnDate, yesterday, returnCarDate, today;
    SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");

    public Formatting(Booking book) {
        this.pickupDate = book.getPickUpDate();
        this.returnDate = book.getReturnDate();
        this.yesterday = CalcYtdDate();
        this.today = TdyDate();
    }

    public Formatting(Booking book, String returnCar) {
        this.pickupDate = book.getPickUpDate();
        this.returnDate = book.getReturnDate();
        this.returnCarDate = book.getReturnCarDate();
        this.today = TdyDate();
    }

    //calculate yesterday date
    private String CalcYtdDate() {
        Date dateToday = new Date();
        final long MILLI_A_DAY = 1000 * 60 * 60 * 24;//millisecond in one day
        long ytdDate = dateToday.getTime() - MILLI_A_DAY;
        Date yes = new Date(ytdDate);
        String ytd = formatter.format(yes);
        return ytd;
    }

    //calculate yesterday date
    private String TdyDate() {
        Date tdyDate = new Date();
        String tdy = formatter.format(tdyDate);
        return tdy;
    }

    //format string to date to do comparison
    public Date PickupDate() throws ParseException {

        Date pickUpD = formatter.parse(pickupDate);

        return pickUpD;
    }

    public Date ReturnDate() throws ParseException {

        Date returnD = formatter.parse(returnDate);

        return returnD;
    }

    public Date YesterdayDate() throws ParseException {

        Date ytd = formatter.parse(yesterday);

        return ytd;
    }

    public Date ReturnCarDate() throws ParseException {

        Date returnD = formatter.parse(returnCarDate);

        return returnD;
    }
    
    public Date TodayDate() throws ParseException {

        Date todayDate = formatter.parse(today);

        return todayDate;
    }    
}
