package data;


import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.text.ParseException;
import java.util.*;


public class RetrieveData {

    public static String[] RetrieveData(String fileName) throws FileNotFoundException {

        // arraylist to store all data
        ArrayList<String> list;
        list = new ArrayList<>();

        //open file to read
        FileInputStream fis = new FileInputStream(fileName);

        //scan file
        Scanner s = new Scanner(fis);

        // retrieve all rows from file
        while (s.hasNextLine()) {

            // add each line into arraylist
            list.add(s.nextLine());
        }

        //convert arrayList to string array
        String[] array;
        array = list.toArray(String[]::new);

        return array;
    }

    public static String ReturnString(String uniqueKey, String fileName,int num1, int num2) throws FileNotFoundException {
        int index = 0;

        String[] fileInfo = RetrieveData.RetrieveData(fileName);

        //create arraylist to store all uniqueKeys
        ArrayList<String> existingUniqueKey
                = new ArrayList<>();

        //create arraylist to store all return value
        ArrayList<String> existingString
                = new ArrayList<>();

        //loop to get each user from fileInfo arraylist
        for (String each : fileInfo) {

            //split the user info
            String[] details = each.split("//");

            //add all uniqueKey to arraylist
            existingUniqueKey.add(details[num1]);

            //add all string to arraylist
            existingString.add(details[num2]);
        }

        //loop the existing uniqueKey and ic  arraylist to check credential            
        for (int i = 0; i < existingUniqueKey.size(); i++) {
            if (uniqueKey.equals(existingUniqueKey.get(i))) {
                index = i;
                break;
            }
        }

        String returnValue = existingString.get(index);

        return returnValue;
    }

    public static String[] Search(String searchValue, String fileName) throws FileNotFoundException {

        String[] info = RetrieveData.RetrieveData(fileName);

        //create arraylist to store all details
        ArrayList<String> list
                = new ArrayList<>();

        //loop to get each record from info arraylist
        for (String each : info) {

            //split the info
            String[] data = each.split("//");

            //avoid redundant data
            Boolean store = false;

            //get details of one record
            for (String detail : data) {

                detail = detail.toLowerCase().strip();
                searchValue = searchValue.toLowerCase().strip();

                if (detail.contains(searchValue) && !store || searchValue.isEmpty() && !store) {
                    //set true to stop adding
                    store = true;

                    //store everything
                    list.add(each);
                }

            }

        }

        // convert list to string array
        String[] details
                = list.toArray(String[]::new);

        return details;
    }

    public static String[] Filter(String sameValue, String fileName, int index) throws FileNotFoundException {

        // modifiedlist to store all filtered records
        ArrayList<String> filteredInfo
                = new ArrayList<>();

        String[] info = RetrieveData.RetrieveData(fileName);

        //loop to get each record from arraylist
        for (String each : info) {

            //split the  info
            String[] data = each.split("//");

            //store info with the right value
            if (data[index].equalsIgnoreCase(sameValue)) {

                filteredInfo.add(each);

            } 

        }

        // convert booking List to string array
        String[] filtered
                = filteredInfo.toArray(String[]::new);

        return filtered;
    }    

    public static String[] Individual(String id, String fileName) throws FileNotFoundException, ParseException {

        String[] info = RetrieveData.RetrieveData(fileName);

        //create arraylist to store all details
        ArrayList<String> list
                = new ArrayList<>();

        //loop to get each record from arraylist
        for (String each : info) {

            //split info
            String[] details = each.split("//");
            
            if(id.equalsIgnoreCase(details[0])){
                
                //add all fields to the list individuall
                list.addAll(Arrays.asList(details));
            }
            
        }

        // convert list to string array
        String[] indvDetails
                = list.toArray(String[]::new);

        return indvDetails;

    } 

}
