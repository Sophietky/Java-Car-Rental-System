
package data;

import java.io.*;
import javax.swing.JOptionPane;

public class UpdateData {

    public static void UpdateData(String[] modifiedList, String fileName) {
        try {
            //write the file
            FileWriter fw = new FileWriter(fileName, false); 
            BufferedWriter bw = new BufferedWriter(fw);
            PrintWriter pw;            
            pw = new PrintWriter(bw);
            for(String eachRow : modifiedList)
            {
                pw.println(eachRow);
            }
            pw.close();
            JOptionPane.showMessageDialog(null, "Data Successfully Updated!","Congratulations!",JOptionPane.INFORMATION_MESSAGE);
        }catch(IOException e){
            JOptionPane.showMessageDialog(null, e);
        }
    }     
    
    
    public static void UpdateFile(String[] modifiedList, String fileName) {
        try {
            //write the file
            FileWriter fw = new FileWriter(fileName, false); 
            BufferedWriter bw = new BufferedWriter(fw);
            PrintWriter pw;            
            pw = new PrintWriter(bw);
            for(String eachRow : modifiedList)
            {
                pw.println(eachRow);
            }
            pw.close();
        }catch(IOException e){
            JOptionPane.showMessageDialog(null, e);
        }
    }
}
