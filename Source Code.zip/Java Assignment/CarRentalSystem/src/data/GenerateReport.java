package data;

import java.io.FileNotFoundException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class GenerateReport {

    public static Integer[] RentalSummary() throws FileNotFoundException {

        //create arraylist to store all info
        ArrayList<Integer> rentalInfo = new ArrayList<>();

        int total = 0, pending = 0, approved = 0, rejected = 0;

        String[] bookingInfo = RetrieveData.RetrieveData("booking.txt");

        //loop to get each booking from arraylist
        for (String eachBooking : bookingInfo) {

            //split the info
            String[] bookData = eachBooking.split("//");

            total++;

            if (bookData[20].equalsIgnoreCase("PENDING")) {
                pending++;
            } else if (bookData[20].equalsIgnoreCase("APPROVED")) {
                approved++;
            } else if (bookData[20].equalsIgnoreCase("REJECTED")) {
                rejected++;
            }

        }

        rentalInfo.add(total);
        rentalInfo.add(pending);
        rentalInfo.add(approved);
        rentalInfo.add(rejected);

        // convert user list to string array
        Integer[] rentalDetails
                = rentalInfo.toArray(Integer[]::new);

        return rentalDetails;
    }

    public static Integer[] CarSummary() throws FileNotFoundException {

        //create arraylist to store all info
        ArrayList<Integer> carInfo = new ArrayList<>();

        //create arraylist to store all info
        ArrayList<String> carBrands = new ArrayList<>();

        //create arraylist to store all info
        ArrayList<String> carModels = new ArrayList<>();

        int available = 0, rented = 0, blocked = 0, brands = 0, models = 0, total = 0;

        String[] allCars = RetrieveData.RetrieveData("car.txt");

        //loop to get each car from arraylist
        for (String eachCar : allCars) {

            //split the info
            String[] carData = eachCar.split("//");

            total++;

            if (carData[8].equalsIgnoreCase("AVAILABLE")) {
                available++;
            } else if (carData[8].equalsIgnoreCase("RENTED")) {
                rented++;
            } else if (carData[8].equalsIgnoreCase("BLOCKED")) {
                blocked++;
            }

            Boolean brandExist = false;
            Boolean modelExist = false;

            for (String brand : carBrands) {

                if (carData[1].equalsIgnoreCase(brand)) {
                    brandExist = true;
                }
            }

            if (brandExist) {

                for (String model : carModels) {

                    if (carData[2].equalsIgnoreCase(model)) {
                        modelExist = true;
                    }
                }

            } else {
                carBrands.add(carData[1]);
                brands++;
            }

            if (!modelExist) {
                carModels.add(carData[2]);
                models++;
            }

        }

        carInfo.add(available);
        carInfo.add(rented);
        carInfo.add(blocked);
        carInfo.add(brands);
        carInfo.add(models);
        carInfo.add(total);

        // convert user list to string array
        Integer[] carDetails
                = carInfo.toArray(Integer[]::new);

        return carDetails;
    }

    public static Double[] Sales() throws FileNotFoundException, ParseException, NumberFormatException {

        //converts string to date with the format
        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy HH:mm");

        String[] bookingInfo = RetrieveData.RetrieveData("booking.txt");

        //create arraylist to store all info
        ArrayList<Double> sales = new ArrayList<>();

        //loop to get each from booking arraylist
        for (String eachBooking : bookingInfo) {

            //split info
            String[] bookingDetails = eachBooking.split("//");

            //converts string to date with the format
            Date retur = sdf.parse(bookingDetails[12] + " " + bookingDetails[15]);

            //today
            Date tdy = new Date();
            SimpleDateFormat sdfYear = new SimpleDateFormat("yyyy");
            double thisYear = Double.parseDouble(sdfYear.format(tdy));
            double year = Double.parseDouble(sdfYear.format(retur));

            double salesThisMonth = 0;
            for (double i = 1; i < 13; i++) {

                //calc sales for this year
                if (thisYear == year) {

                    //get month
                    SimpleDateFormat sdfMonth = new SimpleDateFormat("MM");
                    double month = Double.parseDouble(sdfMonth.format(retur));

                    if (i == month) {

                        salesThisMonth += Double.parseDouble(bookingDetails[21]);
                    } else if (i == 12) {
                        sales.add(salesThisMonth);
                        salesThisMonth = 0;
                    }

                }
            }

        }

        // convert user list to array
        Double[] salesDetails
                = sales.toArray(Double[]::new);

        return salesDetails;
    }

}
