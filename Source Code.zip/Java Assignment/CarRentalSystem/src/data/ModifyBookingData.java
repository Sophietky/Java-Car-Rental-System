package data;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import model.Booking;
import model.CustomerFeedback;

public class ModifyBookingData {

    public static String[] UpdateReturnCar(Booking book) throws FileNotFoundException {

        //get info
        String id = book.getBookID();
        String fine = book.getFine();

        // modifiedlist to store all updated booking
        ArrayList<String> updatedBookingInfo
                = new ArrayList<>();

        String[] bookingInfo = RetrieveData.RetrieveData("booking.txt");

        //loop to get each booking from booking info arraylist
        for (String eachBooking : bookingInfo) {

            //split the booking info
            String[] bookingData = eachBooking.split("//");

            //store booking info of that room
            if (id.equalsIgnoreCase(bookingData[0])) {
                if (bookingData[19].equalsIgnoreCase("FULL PAYMENT")) {
                    bookingData[24] = fine;

                    StringBuilder bookingBd = new StringBuilder();
                    for (int i = 0; i < bookingData.length; i++) {

                        bookingBd.append(bookingData[i]);

                        //last element no need seperator
                        if (i == (bookingData.length - 1)) {
                            break;
                        }
                        bookingBd.append("//");
                    }

                    String bookingDetails = bookingBd.toString();

                    updatedBookingInfo.add(bookingDetails);
                }
            }
            updatedBookingInfo.add(eachBooking);
        }

        // convert booking List to string array
        String[] modifiedBookings
                = updatedBookingInfo.toArray(String[]::new);

        return modifiedBookings;
    }

    public static String[] EditBookingData(Booking booking) throws FileNotFoundException {

        String id = booking.getBookID();

        ArrayList<String> modifiedList
                = new ArrayList<>();

        String[] bookingDetails = RetrieveData.RetrieveData("booking.txt");

        //loop to get each booking from booking details arraylist
        for (String eachBooking : bookingDetails) {

            //split the booking info
            String[] bookingData = eachBooking.split("//");

            //store booking info
            if (id.equals(bookingData[0])) {
                bookingData[2] = booking.getName();
                bookingData[3] = booking.getEmail();
                bookingData[4] = booking.getContact();
                bookingData[5] = booking.getNationality();

                bookingData[10] = booking.getReturnLocation();
                bookingData[17] = booking.getRemarks();
                bookingData[16] = booking.getRentpurpose();
                bookingData[18] = booking.getPaymentMethod();
                bookingData[20] = booking.getStatus();

                StringBuilder bookingBd = new StringBuilder();
                for (int i = 0; i < bookingData.length; i++) {

                    bookingBd.append(bookingData[i]);

                    //last element no need seperator
                    if (i == (bookingData.length - 1)) {
                        break;
                    }
                    bookingBd.append("//");
                }

                String bookings = bookingBd.toString();

                modifiedList.add(bookings);
            }

            modifiedList.add(eachBooking);
        }

        // convert booking List to string array
        String[] modifiedBooking
                = modifiedList.toArray(String[]::new);

        return modifiedBooking;
    }

    public static String[] DeleteBooking(String filepath, String removeTerm) throws FileNotFoundException, IOException {

        String id = removeTerm;

        ArrayList<String> modifiedList
                = new ArrayList<>();

        String[] bookingDetails = RetrieveData.RetrieveData(filepath);

        //loop to get each booking from booking details arraylist
        for (String eachBooking : bookingDetails) {

            //split the booking info
            String[] bookingData = eachBooking.split("//");

            //store booking info
            if (id.equals(bookingData[0])) {
                continue;
            }

            modifiedList.add(eachBooking);
        }

        // convert booking List to string array
        String[] modifiedData
                = modifiedList.toArray(String[]::new);

        return modifiedData;
    }

    public static String[] UpdateField(Booking book, int num, String change) throws FileNotFoundException {

        //get info
        String id = book.getBookID();

        // modifiedlist to store all updated booking
        ArrayList<String> updatedBookingInfo
                = new ArrayList<>();

        String[] bookingInfo = RetrieveData.RetrieveData("booking.txt");

        //loop to get each booking from booking info arraylist
        for (String eachBooking : bookingInfo) {

            //split the booking info
            String[] bookingData = eachBooking.split("//");

            //store booking info of that room
            if (id.equalsIgnoreCase(bookingData[0])) {

                if (bookingData[num].equalsIgnoreCase(change)) {
                    JOptionPane.showMessageDialog(null, "Booking Already " + change + " !", "Error!", JOptionPane.WARNING_MESSAGE);

                } else {
                    bookingData[num] = change;
                    JOptionPane.showMessageDialog(null, "Booking Status Successfully Updated!", "Congratulations!", JOptionPane.INFORMATION_MESSAGE);

                    StringBuilder bookingBd = new StringBuilder();
                    for (int i = 0; i < bookingData.length; i++) {

                        bookingBd.append(bookingData[i]);

                        //last element no need seperator
                        if (i == (bookingData.length - 1)) {
                            break;
                        }
                        bookingBd.append("//");
                    }

                    String bookingDetails = bookingBd.toString();

                    updatedBookingInfo.add(bookingDetails);

                }

            }

            updatedBookingInfo.add(eachBooking);

        }

        // convert booking List to string array
        String[] modifiedBookings
                = updatedBookingInfo.toArray(String[]::new);

        return modifiedBookings;
    }

    public static String[] EditRating(CustomerFeedback feed) throws FileNotFoundException {

        String id = feed.getBookId();

        ArrayList<String> modifiedList
                = new ArrayList<>();

        String[] bookingDetails = RetrieveData.RetrieveData("booking.txt");

        //loop to get each booking from booking details arraylist
        for (String eachBooking : bookingDetails) {

            //split the booking info
            String[] bookingData = eachBooking.split("//");

            //store booking info
            if (id.equals(bookingData[0])) {

                bookingData[25] = feed.getTotal();
                bookingData[26] = feed.getComment();
                
                StringBuilder bookingBd = new StringBuilder();
                for (int i = 0; i < bookingData.length; i++) {

                    bookingBd.append(bookingData[i]);

                    //last element no need seperator
                    if (i == (bookingData.length - 1)) {
                        break;
                    }
                    bookingBd.append("//");
                }

                String bookings = bookingBd.toString();

                modifiedList.add(bookings);
            }

            modifiedList.add(eachBooking);

        }

        // convert booking List to string array
        String[] modifiedBooking
                = modifiedList.toArray(String[]::new);

        return modifiedBooking;
    }
}
