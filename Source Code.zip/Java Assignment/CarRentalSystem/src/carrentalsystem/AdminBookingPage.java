package carrentalsystem;

import data.*;
import model.*;
import java.awt.HeadlessException;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;


public class AdminBookingPage extends javax.swing.JFrame {

    public AdminBookingPage() throws FileNotFoundException {
        initComponents();

    }

    public AdminBookingPage(User user, String type, Car car, Booking booking) throws FileNotFoundException {
        initComponents();

        passTypeLbl.setText(user.getStatus());
        passLbl.setText(user.getIc());
        passNumPlateLbl.setText(car.getNumberPlate());

        if (type.equalsIgnoreCase("Make Booking")) {

            //set title
            titleLbl.setText("Make Booking");

            //hide button
            updateBookingBtn.setVisible(false);
            deleteBookingBtn.setVisible(false);

            String[] carInfo = RetrieveData.RetrieveData("car.txt");

            //loop to get each car from carInfo arraylist
            for (String eachCar : carInfo) {

                //split the car info
                String[] carDetails = eachCar.split("//");

                if (carDetails[0].equalsIgnoreCase(car.getNumberPlate())) {

                    //calculate price
                    int price = Integer.parseInt(carDetails[5]);
                    Double uponCollection = price * 0.85;
                    Double payOnline = price * 0.15;

                    //convert to string
                    String upon = String.valueOf(uponCollection);
                    String online = String.valueOf(payOnline);

                    //set text
                    setBrandModelLbl.setText(carDetails[1] + " " + "&" + " " + carDetails[2]);
                    setPickupDateTimeLbl.setText(booking.getPickUpDate() + " " + "&" + " " + booking.getPickUpTime());
                    setReturnDateTimeLbl.setText(booking.getReturnDate() + " " + "&" + " " + booking.getReturnTime());
                    setTotalRentalFeeLbl.setText(carDetails[5]);
                    setPayUponCollection.setText(upon);
                    setPayOnlineLbl.setText(online);
                    setPayNowLbl.setText(online);
                    setTotalLbl.setText(online);
                    setLocationLbl.setText(booking.getPickupLocation());
                    passBrandLbl.setText(carDetails[1]);
                    passModelLbl.setText(carDetails[2]);
                    passPickDtLbl.setText(booking.getPickUpDate());
                    passPickTimeLbl.setText(booking.getPickUpTime());
                    passReturnDtLbl.setText(booking.getReturnDate());
                    passReturnTimeLbl.setText(booking.getReturnTime());
                }
            }

        }
    }

    public AdminBookingPage(User user, String type, Booking booking) throws FileNotFoundException {
        initComponents();

        passTypeLbl.setText(user.getStatus());

        if (type.equalsIgnoreCase("Update Booking")) {

            //set title
            titleLbl.setText("Update Booking");

            //hide button
            makeBookingBtn.setVisible(false);
            deleteBookingBtn.setVisible(false);

        } else if (type.equalsIgnoreCase("Cancel Booking")) {

            //set title
            titleLbl.setText("Cancel Booking");

            //hide button
            makeBookingBtn.setVisible(false);
            updateBookingBtn.setVisible(false);

        }

        passBookingLbl.setText(booking.getBookID());

        String[] bookingInfo = RetrieveData.RetrieveData("booking.txt");
        //loop to get each car from car info arraylist
        for (String eachBooking : bookingInfo) {
            //split the car info
            String[] bookingData = eachBooking.split("//");
            String bookId = booking.getBookID();

            if (bookingData[0].equalsIgnoreCase(bookId)) {
                //customer info
                txtIc.setText(bookingData[1]);
                txtIc.setEditable(false);
                txtName.setText(bookingData[2]);
                txtEmail.setText(bookingData[3]);
                txtReEnterEmail.setText(bookingData[3]);
                txtPhone.setText(bookingData[4]);
                txtNationality.setText(bookingData[5]);

                //rental info
                setLocationLbl.setText(bookingData[9]);
                returnLocationComboBox.setSelectedItem(bookingData[10]);

                //Rent purpose Radio button 16
                if (bookingData[16].equalsIgnoreCase("Leisure")) {
                    leisureRBtn.setSelected(true);
                } else if (bookingData[16].equalsIgnoreCase("Business")) {
                    businessRBtn.setSelected(true);
                } else if (bookingData[16].equalsIgnoreCase("Others")) {
                    othersRBtn.setSelected(true);
                }

                txtRemarks.setText(bookingData[17]);

                //Car rental info
                setBrandModelLbl.setText(bookingData[7] + "" + "&" + "" + bookingData[8]);
                setPickupDateTimeLbl.setText(bookingData[11] + "" + "&" + "" + bookingData[14]);
                setReturnDateTimeLbl.setText((bookingData[12] + "" + "&" + "" + bookingData[15]));

                //Payment info
                setTotalRentalFeeLbl.setText(bookingData[21]);
                setPayUponCollection.setText(bookingData[22]);
                setPayOnlineLbl.setText(bookingData[23]);
                setPayNowLbl.setText(bookingData[23]);
                setTotalLbl.setText(bookingData[23]);

                //Payment method 18
                if (bookingData[18].equalsIgnoreCase("Credit/Debit Card")) {
                    cardRBtn.setSelected(true);
                } else if (bookingData[18].equalsIgnoreCase("Visa/Master/Paypal/Alipay")) {
                    visaRBtn.setSelected(true);
                } else if (bookingData[18].equalsIgnoreCase("E-Wallet")) {
                    ewalletRBtn.setSelected(true);
                } else if (bookingData[18].equalsIgnoreCase("Online Banking")) {
                    onlineRBtn.setSelected(true);
                } else if (bookingData[18].equalsIgnoreCase("Convenient Store")) {
                    storeRBtn.setSelected(true);
                }
            }

        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        rentPurposeBtnGrp = new javax.swing.ButtonGroup();
        paymentMethodBtnGrp = new javax.swing.ButtonGroup();
        backBtn = new javax.swing.JButton();
        titleLbl = new javax.swing.JLabel();
        logoutBtn = new javax.swing.JButton();
        closeBtn = new javax.swing.JButton();
        rentalInfoLbl = new javax.swing.JLabel();
        customerInfoLbl = new javax.swing.JLabel();
        rentalInforLbl = new javax.swing.JLabel();
        paymentInfoLbl = new javax.swing.JLabel();
        emailLbl = new javax.swing.JLabel();
        txtReEnterEmail = new javax.swing.JTextField();
        nameLbl = new javax.swing.JLabel();
        reEnterEmailLbl = new javax.swing.JLabel();
        nationalityLbl = new javax.swing.JLabel();
        phoneLbl = new javax.swing.JLabel();
        txtNationality = new javax.swing.JTextField();
        txtEmail = new javax.swing.JTextField();
        txtPhone = new javax.swing.JTextField();
        txtName = new javax.swing.JTextField();
        returnLocationLbl = new javax.swing.JLabel();
        rentPurposeLbl = new javax.swing.JLabel();
        remarksLbl = new javax.swing.JLabel();
        txtRemarks = new javax.swing.JTextField();
        setLocationLbl = new javax.swing.JLabel();
        returnLocationComboBox = new javax.swing.JComboBox<>();
        pickupLocationLbl = new javax.swing.JLabel();
        othersRBtn = new javax.swing.JRadioButton();
        leisureRBtn = new javax.swing.JRadioButton();
        businessRBtn = new javax.swing.JRadioButton();
        pickupDateLbl = new javax.swing.JLabel();
        setPickupDateTimeLbl = new javax.swing.JLabel();
        paymentMethodLbl = new javax.swing.JLabel();
        setReturnDateTimeLbl = new javax.swing.JLabel();
        setTotalRentalFeeLbl = new javax.swing.JLabel();
        setPayNowLbl = new javax.swing.JLabel();
        setBrandModelLbl = new javax.swing.JLabel();
        totalRentalFeeLbl = new javax.swing.JLabel();
        payUponCollectionLbl = new javax.swing.JLabel();
        setPayUponCollection = new javax.swing.JLabel();
        payOnlineLbl = new javax.swing.JLabel();
        setPayOnlineLbl = new javax.swing.JLabel();
        carLbl = new javax.swing.JLabel();
        payNowLbl = new javax.swing.JLabel();
        totalLbl = new javax.swing.JLabel();
        setTotalLbl = new javax.swing.JLabel();
        returnDateLbl = new javax.swing.JLabel();
        ewalletRBtn = new javax.swing.JRadioButton();
        cardRBtn = new javax.swing.JRadioButton();
        visaRBtn = new javax.swing.JRadioButton();
        storeRBtn = new javax.swing.JRadioButton();
        onlineRBtn = new javax.swing.JRadioButton();
        resetBtn = new javax.swing.JButton();
        deleteBookingBtn = new javax.swing.JButton();
        updateBookingBtn = new javax.swing.JButton();
        makeBookingBtn = new javax.swing.JButton();
        txtIc = new javax.swing.JTextField();
        icLbl = new javax.swing.JLabel();
        bgLbl = new javax.swing.JLabel();
        passLbl = new javax.swing.JLabel();
        passBookingLbl = new javax.swing.JLabel();
        passNumPlateLbl = new javax.swing.JLabel();
        passBrandLbl = new javax.swing.JLabel();
        passModelLbl = new javax.swing.JLabel();
        passPickDtLbl = new javax.swing.JLabel();
        passPickTimeLbl = new javax.swing.JLabel();
        passReturnDtLbl = new javax.swing.JLabel();
        passReturnTimeLbl = new javax.swing.JLabel();
        passTypeLbl = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(1280, 720));
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        backBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/back.png"))); // NOI18N
        backBtn.setBorderPainted(false);
        backBtn.setContentAreaFilled(false);
        backBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backBtnActionPerformed(evt);
            }
        });
        getContentPane().add(backBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(1010, 20, -1, -1));

        titleLbl.setFont(new java.awt.Font("Eras Bold ITC", 1, 36)); // NOI18N
        titleLbl.setForeground(new java.awt.Color(255, 255, 255));
        titleLbl.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        titleLbl.setText("Booking");
        getContentPane().add(titleLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 30, 1280, 72));

        logoutBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/logout.png"))); // NOI18N
        logoutBtn.setBorderPainted(false);
        logoutBtn.setContentAreaFilled(false);
        logoutBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                logoutBtnActionPerformed(evt);
            }
        });
        getContentPane().add(logoutBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(1110, 30, -1, -1));

        closeBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/close.png"))); // NOI18N
        closeBtn.setBorderPainted(false);
        closeBtn.setContentAreaFilled(false);
        closeBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                closeBtnActionPerformed(evt);
            }
        });
        getContentPane().add(closeBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(1180, 30, -1, -1));

        rentalInfoLbl.setFont(new java.awt.Font("Eras Bold ITC", 0, 18)); // NOI18N
        rentalInfoLbl.setText("RENTAL INFO");
        getContentPane().add(rentalInfoLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 400, 190, -1));

        customerInfoLbl.setFont(new java.awt.Font("Eras Bold ITC", 0, 18)); // NOI18N
        customerInfoLbl.setText("CUSTOMER INFO");
        getContentPane().add(customerInfoLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 130, 190, -1));

        rentalInforLbl.setFont(new java.awt.Font("Eras Bold ITC", 0, 18)); // NOI18N
        rentalInforLbl.setText("RENTAL INFO");
        rentalInforLbl.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        getContentPane().add(rentalInforLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 130, 140, -1));

        paymentInfoLbl.setFont(new java.awt.Font("Eras Bold ITC", 0, 18)); // NOI18N
        paymentInfoLbl.setText("PAYMENT INFO");
        getContentPane().add(paymentInfoLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(1030, 130, 150, -1));

        emailLbl.setFont(new java.awt.Font("Eras Medium ITC", 1, 18)); // NOI18N
        emailLbl.setText("Email Address");
        getContentPane().add(emailLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 220, 140, -1));

        txtReEnterEmail.setFont(new java.awt.Font("Eras Medium ITC", 0, 14)); // NOI18N
        getContentPane().add(txtReEnterEmail, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 250, 270, -1));

        nameLbl.setFont(new java.awt.Font("Eras Medium ITC", 1, 18)); // NOI18N
        nameLbl.setText("Name");
        getContentPane().add(nameLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 160, 60, -1));

        reEnterEmailLbl.setFont(new java.awt.Font("Eras Medium ITC", 1, 18)); // NOI18N
        reEnterEmailLbl.setText("Re-Enter Email Address");
        getContentPane().add(reEnterEmailLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 250, 210, -1));

        nationalityLbl.setFont(new java.awt.Font("Eras Medium ITC", 1, 18)); // NOI18N
        nationalityLbl.setText("Nationality");
        getContentPane().add(nationalityLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 310, 140, -1));

        phoneLbl.setFont(new java.awt.Font("Eras Medium ITC", 1, 18)); // NOI18N
        phoneLbl.setText("Phone Number");
        getContentPane().add(phoneLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 280, 140, -1));

        txtNationality.setFont(new java.awt.Font("Eras Medium ITC", 0, 14)); // NOI18N
        getContentPane().add(txtNationality, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 310, 270, -1));

        txtEmail.setFont(new java.awt.Font("Eras Medium ITC", 0, 14)); // NOI18N
        getContentPane().add(txtEmail, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 220, 270, -1));

        txtPhone.setFont(new java.awt.Font("Eras Medium ITC", 0, 14)); // NOI18N
        getContentPane().add(txtPhone, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 280, 270, -1));

        txtName.setFont(new java.awt.Font("Eras Medium ITC", 0, 14)); // NOI18N
        getContentPane().add(txtName, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 160, 270, -1));

        returnLocationLbl.setFont(new java.awt.Font("Eras Medium ITC", 1, 18)); // NOI18N
        returnLocationLbl.setText("Return Location");
        getContentPane().add(returnLocationLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 480, 140, -1));

        rentPurposeLbl.setFont(new java.awt.Font("Eras Medium ITC", 1, 18)); // NOI18N
        rentPurposeLbl.setText("Rent Purpose");
        getContentPane().add(rentPurposeLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 520, 210, -1));

        remarksLbl.setFont(new java.awt.Font("Eras Medium ITC", 1, 18)); // NOI18N
        remarksLbl.setText("Remarks");
        getContentPane().add(remarksLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 560, 140, -1));

        txtRemarks.setFont(new java.awt.Font("Eras Medium ITC", 0, 14)); // NOI18N
        txtRemarks.setText("Adult x2 , Child x2");
        getContentPane().add(txtRemarks, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 560, 270, -1));

        setLocationLbl.setFont(new java.awt.Font("Eras Medium ITC", 0, 18)); // NOI18N
        setLocationLbl.setText("Selected Location");
        getContentPane().add(setLocationLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 440, 270, -1));

        returnLocationComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Ampang Area", "Cheras Area", "Cyberjaya Area", "Damansara", "Kepong Area", "Klang Area", "Klang Valley Area", "KLCC", "KLIA Area", "KLIA 2 Area", "KL Sentral", "Kota Damansara", "Kota Kemuning", "Kuala Lumpur Area", "Pandan Indah Area", "Petaling Jaya Area", "Puchong Area", "Putra Heights", "Putrajaya Area", "Sepang Area", "Shah Alam Area", "Subang Airport", "Subang Jaya Area" }));
        getContentPane().add(returnLocationComboBox, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 480, 270, -1));

        pickupLocationLbl.setFont(new java.awt.Font("Eras Medium ITC", 1, 18)); // NOI18N
        pickupLocationLbl.setText("Pick-up Location");
        getContentPane().add(pickupLocationLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 440, 150, -1));

        rentPurposeBtnGrp.add(othersRBtn);
        othersRBtn.setFont(new java.awt.Font("Eras Light ITC", 0, 14)); // NOI18N
        othersRBtn.setText("Others");
        getContentPane().add(othersRBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 520, -1, -1));

        rentPurposeBtnGrp.add(leisureRBtn);
        leisureRBtn.setFont(new java.awt.Font("Eras Light ITC", 0, 14)); // NOI18N
        leisureRBtn.setText("Leisure");
        getContentPane().add(leisureRBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 520, -1, -1));

        rentPurposeBtnGrp.add(businessRBtn);
        businessRBtn.setFont(new java.awt.Font("Eras Light ITC", 0, 14)); // NOI18N
        businessRBtn.setText("Business");
        getContentPane().add(businessRBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 520, -1, -1));

        pickupDateLbl.setFont(new java.awt.Font("Eras Demi ITC", 1, 18)); // NOI18N
        pickupDateLbl.setText("Pick-up Date:");
        getContentPane().add(pickupDateLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 220, 150, -1));

        setPickupDateTimeLbl.setFont(new java.awt.Font("Eras Medium ITC", 0, 14)); // NOI18N
        setPickupDateTimeLbl.setText("Pick-up Date , Time");
        getContentPane().add(setPickupDateTimeLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 250, 190, -1));

        paymentMethodLbl.setFont(new java.awt.Font("Eras Demi ITC", 1, 18)); // NOI18N
        paymentMethodLbl.setText("Please Choose One Payment Method:");
        getContentPane().add(paymentMethodLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(790, 450, 360, -1));

        setReturnDateTimeLbl.setFont(new java.awt.Font("Eras Medium ITC", 0, 14)); // NOI18N
        setReturnDateTimeLbl.setText("Return Date , Time");
        getContentPane().add(setReturnDateTimeLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 310, 190, -1));

        setTotalRentalFeeLbl.setFont(new java.awt.Font("Eras Medium ITC", 0, 14)); // NOI18N
        setTotalRentalFeeLbl.setForeground(new java.awt.Color(153, 51, 255));
        setTotalRentalFeeLbl.setText(" XXX.XX");
        getContentPane().add(setTotalRentalFeeLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(1170, 180, 90, -1));

        setPayNowLbl.setFont(new java.awt.Font("Eras Demi ITC", 1, 18)); // NOI18N
        setPayNowLbl.setForeground(new java.awt.Color(51, 153, 255));
        setPayNowLbl.setText("XXX.XX");
        getContentPane().add(setPayNowLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(1120, 300, 110, -1));

        setBrandModelLbl.setFont(new java.awt.Font("Eras Medium ITC", 0, 14)); // NOI18N
        setBrandModelLbl.setText("Brand & Model");
        getContentPane().add(setBrandModelLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 190, 190, -1));

        totalRentalFeeLbl.setFont(new java.awt.Font("Eras Demi ITC", 1, 14)); // NOI18N
        totalRentalFeeLbl.setForeground(new java.awt.Color(153, 51, 255));
        totalRentalFeeLbl.setText("Total Rental Fee: RM");
        getContentPane().add(totalRentalFeeLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(1020, 180, 150, -1));

        payUponCollectionLbl.setFont(new java.awt.Font("Eras Demi ITC", 1, 14)); // NOI18N
        payUponCollectionLbl.setForeground(new java.awt.Color(255, 0, 153));
        payUponCollectionLbl.setText("Pay Upon Collection: RM");
        getContentPane().add(payUponCollectionLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(990, 210, -1, -1));

        setPayUponCollection.setFont(new java.awt.Font("Eras Medium ITC", 0, 14)); // NOI18N
        setPayUponCollection.setForeground(new java.awt.Color(255, 0, 153));
        setPayUponCollection.setText(" XXX.XX");
        getContentPane().add(setPayUponCollection, new org.netbeans.lib.awtextra.AbsoluteConstraints(1170, 210, 90, -1));

        payOnlineLbl.setFont(new java.awt.Font("Eras Demi ITC", 1, 14)); // NOI18N
        payOnlineLbl.setForeground(new java.awt.Color(51, 51, 255));
        payOnlineLbl.setText("Pay Online: RM");
        getContentPane().add(payOnlineLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(1060, 240, -1, -1));

        setPayOnlineLbl.setFont(new java.awt.Font("Eras Medium ITC", 0, 14)); // NOI18N
        setPayOnlineLbl.setForeground(new java.awt.Color(51, 51, 255));
        setPayOnlineLbl.setText(" XXX.XX");
        getContentPane().add(setPayOnlineLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(1170, 240, 90, -1));

        carLbl.setFont(new java.awt.Font("Eras Demi ITC", 1, 18)); // NOI18N
        carLbl.setText("Car:");
        getContentPane().add(carLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 160, 150, -1));

        payNowLbl.setFont(new java.awt.Font("Eras Demi ITC", 1, 18)); // NOI18N
        payNowLbl.setForeground(new java.awt.Color(51, 153, 255));
        payNowLbl.setText("Pay Now: RM");
        getContentPane().add(payNowLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(990, 300, 130, -1));

        totalLbl.setBackground(new java.awt.Color(0, 0, 0));
        totalLbl.setFont(new java.awt.Font("Eras Demi ITC", 1, 24)); // NOI18N
        totalLbl.setForeground(new java.awt.Color(102, 255, 0));
        totalLbl.setText("Total: RM");
        totalLbl.setOpaque(true);
        getContentPane().add(totalLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(840, 400, 120, -1));

        setTotalLbl.setBackground(new java.awt.Color(0, 0, 0));
        setTotalLbl.setFont(new java.awt.Font("Eras Demi ITC", 1, 24)); // NOI18N
        setTotalLbl.setForeground(new java.awt.Color(102, 255, 0));
        setTotalLbl.setText(" XXX.XX");
        setTotalLbl.setOpaque(true);
        getContentPane().add(setTotalLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(960, 400, 150, -1));

        returnDateLbl.setFont(new java.awt.Font("Eras Demi ITC", 1, 18)); // NOI18N
        returnDateLbl.setText("Return Date:");
        getContentPane().add(returnDateLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 280, 150, -1));

        paymentMethodBtnGrp.add(ewalletRBtn);
        ewalletRBtn.setFont(new java.awt.Font("Eras Medium ITC", 0, 18)); // NOI18N
        ewalletRBtn.setText("E-Wallet");
        getContentPane().add(ewalletRBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 560, -1, -1));

        paymentMethodBtnGrp.add(cardRBtn);
        cardRBtn.setFont(new java.awt.Font("Eras Medium ITC", 0, 18)); // NOI18N
        cardRBtn.setText("Credit/Debit Card");
        getContentPane().add(cardRBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 480, -1, -1));

        paymentMethodBtnGrp.add(visaRBtn);
        visaRBtn.setFont(new java.awt.Font("Eras Medium ITC", 0, 18)); // NOI18N
        visaRBtn.setText("Visa/Master/Paypal/Alipay");
        getContentPane().add(visaRBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 520, -1, -1));

        paymentMethodBtnGrp.add(storeRBtn);
        storeRBtn.setFont(new java.awt.Font("Eras Medium ITC", 0, 18)); // NOI18N
        storeRBtn.setText("Convenient Store");
        getContentPane().add(storeRBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(1010, 520, -1, -1));

        paymentMethodBtnGrp.add(onlineRBtn);
        onlineRBtn.setFont(new java.awt.Font("Eras Medium ITC", 0, 18)); // NOI18N
        onlineRBtn.setText("Online Banking");
        getContentPane().add(onlineRBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(1010, 480, -1, -1));

        resetBtn.setFont(new java.awt.Font("Eras Bold ITC", 0, 18)); // NOI18N
        resetBtn.setForeground(new java.awt.Color(0, 51, 255));
        resetBtn.setText("Reset");
        resetBtn.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 255), 2));
        resetBtn.setContentAreaFilled(false);
        getContentPane().add(resetBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 640, 130, 50));

        deleteBookingBtn.setFont(new java.awt.Font("Eras Bold ITC", 0, 18)); // NOI18N
        deleteBookingBtn.setForeground(new java.awt.Color(255, 0, 51));
        deleteBookingBtn.setText("Delete Booking");
        deleteBookingBtn.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 0, 0), 2));
        deleteBookingBtn.setContentAreaFilled(false);
        deleteBookingBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteBookingBtnActionPerformed(evt);
            }
        });
        getContentPane().add(deleteBookingBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 640, 170, 50));

        updateBookingBtn.setFont(new java.awt.Font("Eras Bold ITC", 0, 18)); // NOI18N
        updateBookingBtn.setForeground(new java.awt.Color(255, 0, 255));
        updateBookingBtn.setText("Update Booking");
        updateBookingBtn.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 0, 255), 2));
        updateBookingBtn.setContentAreaFilled(false);
        updateBookingBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateBookingBtnActionPerformed(evt);
            }
        });
        getContentPane().add(updateBookingBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 640, 170, 50));

        makeBookingBtn.setFont(new java.awt.Font("Eras Bold ITC", 0, 18)); // NOI18N
        makeBookingBtn.setForeground(new java.awt.Color(153, 0, 255));
        makeBookingBtn.setText("Make Booking");
        makeBookingBtn.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 0, 255), 2));
        makeBookingBtn.setContentAreaFilled(false);
        makeBookingBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                makeBookingBtnActionPerformed(evt);
            }
        });
        getContentPane().add(makeBookingBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 640, 160, 50));

        txtIc.setFont(new java.awt.Font("Eras Medium ITC", 0, 14)); // NOI18N
        getContentPane().add(txtIc, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 190, 270, -1));

        icLbl.setFont(new java.awt.Font("Eras Medium ITC", 1, 18)); // NOI18N
        icLbl.setText("IC");
        getContentPane().add(icLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 190, 60, -1));

        bgLbl.setFont(new java.awt.Font("Eras Demi ITC", 1, 24)); // NOI18N
        bgLbl.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/bookingBg.png"))); // NOI18N
        getContentPane().add(bgLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        passLbl.setText("jLabel1");
        getContentPane().add(passLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 670, -1, -1));

        passBookingLbl.setText("jLabel1");
        getContentPane().add(passBookingLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 90, -1, -1));
        getContentPane().add(passNumPlateLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 670, -1, -1));
        getContentPane().add(passBrandLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 650, -1, -1));
        getContentPane().add(passModelLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 680, -1, -1));
        getContentPane().add(passPickDtLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 630, -1, -1));
        getContentPane().add(passPickTimeLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 680, -1, -1));
        getContentPane().add(passReturnDtLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 650, -1, -1));
        getContentPane().add(passReturnTimeLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 680, -1, -1));
        getContentPane().add(passTypeLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 90, -1, -1));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void backBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backBtnActionPerformed

        try {
            User user = new User();
            user.setStatus(passTypeLbl.getText());

            setVisible(false);
            new AdminBooking(user, "Manage Booking").setVisible(true);

        } catch (FileNotFoundException ex) {
            JOptionPane.showMessageDialog(this, ex);
        }

    }//GEN-LAST:event_backBtnActionPerformed

    private void logoutBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_logoutBtnActionPerformed
        int confirmLogout = JOptionPane.showConfirmDialog(null, "Do you really want to leave Car Rental System?", "Please Select", JOptionPane.YES_NO_OPTION);
        if (confirmLogout == 0) {

            try {

                String[] newRecord = ModifyUserData.LogoutRecord();
                UpdateData.UpdateFile(newRecord, "LoginRecord.txt");

                setVisible(false);
                new Home().setVisible(true);

            } catch (FileNotFoundException ex) {
                JOptionPane.showMessageDialog(this, ex);
            }
        }
    }//GEN-LAST:event_logoutBtnActionPerformed

    private void closeBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_closeBtnActionPerformed
        int confirmClose = JOptionPane.showConfirmDialog(null, "Do you really want to exit Premium Car Rental System ?", "Please Select", JOptionPane.YES_NO_OPTION);
        if (confirmClose == 0) {
            System.exit(0);
        }
    }//GEN-LAST:event_closeBtnActionPerformed

    private void updateBookingBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateBookingBtnActionPerformed
        try {
            Booking book = new Booking();

            //get booking id
            String id = passBookingLbl.getText();
            book.setBookID(id);

            //customer info
            String name = txtName.getText();
            String email = txtEmail.getText();
            String phone = txtPhone.getText();
            String nationality = txtNationality.getText();

            book.setName(name);
            book.setEmail(email);
            book.setContact(phone);
            book.setNationality(nationality);

            //rental info
            String location = setLocationLbl.getText();
            String returnLocation = returnLocationComboBox.getSelectedItem().toString();
            String remark = txtRemarks.getText();

            book.setPickupLocation(location);
            book.setReturnLocation(returnLocation);
            book.setRemarks(remark);

            if (leisureRBtn.isSelected()) {
                book.setRentpurpose("Leisure");
            } else if (businessRBtn.isSelected()) {
                book.setRentpurpose("Business");
            } else if (othersRBtn.isSelected()) {
                book.setRentpurpose("Others");
            } else {
                book.setRentpurpose("");
            }

            //payment method
            if (cardRBtn.isSelected()) {
                book.setPaymentMethod("Credit/Debit Card");
            } else if (visaRBtn.isSelected()) {
                book.setPaymentMethod("Visa/Master/Paypal/Alipay");
            } else if (ewalletRBtn.isSelected()) {
                book.setPaymentMethod("E-Wallet");
            } else if (onlineRBtn.isSelected()) {
                book.setPaymentMethod("Online Banking");
            } else if (storeRBtn.isSelected()) {
                book.setPaymentMethod("Convenient Store");
            } else {
                book.setPaymentMethod("");
            }

            book.setStatus("APPROVED");
            
            Boolean dataValid = DataValidation.UpdateBookingValidation(book);

            if (!txtEmail.getText().equalsIgnoreCase(txtReEnterEmail.getText())) {
                JOptionPane.showMessageDialog(this, "Your email and re-enter email do not match!\nPlease ensure you entered the correct email.", "Warning!", JOptionPane.WARNING_MESSAGE);
                dataValid = false;
            }

            if (dataValid) {
                //check the Booking is Exist or not
                Boolean existBooking = ValidateBooking.ExistingBooking(id);

                if (existBooking) {

                    //modify booking
                    String[] modifiedBooking = ModifyBookingData.EditBookingData(book);

                    //store modify list
                    UpdateData.UpdateData(modifiedBooking, "booking.txt");

                    //go back
                    User user = new User();
                    user.setStatus(passTypeLbl.getText());

                    setVisible(false);
                    new AdminBooking(user, "Manage Booking").setVisible(true);

                }
            }
        } catch (FileNotFoundException a) {
            JOptionPane.showMessageDialog(null, a);
        }
    }//GEN-LAST:event_updateBookingBtnActionPerformed

    private void deleteBookingBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteBookingBtnActionPerformed

        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy HH:mm");

        try {
            String id = passBookingLbl.getText();
            int confirmLogout = JOptionPane.showConfirmDialog(null, "Do you really want to DELETE THE BOOKING ?", "Please Select", JOptionPane.YES_NO_OPTION);
            if (confirmLogout == 0) {

                Date now = new Date();
                String tdy = sdf.format(now);
                Date today = sdf.parse(tdy);

                String date = RetrieveData.ReturnString(id, "booking.txt", 0, 11);
                String time = RetrieveData.ReturnString(id, "booking.txt", 0, 14);

                Date pickUpDate = sdf.parse(date + " " + time);

                //2 days before pickup date
                Calendar c = Calendar.getInstance();
                c.setTime(pickUpDate);
                c.add(Calendar.DAY_OF_MONTH, -2);
                String dt = sdf.format(c.getTime());
                Date dateTime = sdf.parse(dt);

                if (today.after(dateTime) && today.before(pickUpDate)) {
                    JOptionPane.showMessageDialog(null, "Unable to cancel the booking within 2 days");
                    
                }else if (today.after(pickUpDate)) {
                    JOptionPane.showMessageDialog(null, "Unable to cancel the booking that already started");
                    
                }else if(today.before(dateTime)){

                    //modify booking
                    String[] modifiedBooking = ModifyBookingData.DeleteBooking("booking.txt", id);

                    //store modify list
                    UpdateData.UpdateData(modifiedBooking, "booking.txt");
                    
                    //go back
                    User user = new User();
                    user.setStatus(passTypeLbl.getText());

                    setVisible(false);
                    new AdminBooking(user, "Manage Booking").setVisible(true);            
                    
                }

            }

        } catch (HeadlessException | ParseException e) {
            JOptionPane.showMessageDialog(null, "error");
        } catch (FileNotFoundException ex) {
            Logger.getLogger(CustomerBookingPage.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(CustomerBookingPage.class.getName()).log(Level.SEVERE, null, ex);
        }

    }//GEN-LAST:event_deleteBookingBtnActionPerformed

    private void makeBookingBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_makeBookingBtnActionPerformed

        //set all the values
        Booking book = new Booking();
        book.setIc(txtIc.getText());
        book.setName(txtName.getText());
        book.setEmail(txtEmail.getText());
        book.setContact(txtPhone.getText());
        book.setNationality(txtNationality.getText());
        book.setNumberPlate(passNumPlateLbl.getText());
        book.setCarBrand(passBrandLbl.getText());
        book.setModel(passModelLbl.getText());
        book.setPickupLocation(setLocationLbl.getText());
        book.setReturnLocation(returnLocationComboBox.getSelectedItem().toString());
        book.setPickUpDate(passPickDtLbl.getText());
        book.setReturnDate(passReturnDtLbl.getText());
        book.setPickUpTime(passPickTimeLbl.getText());
        book.setReturnTime(passReturnTimeLbl.getText());

        if (leisureRBtn.isSelected()) {
            book.setRentpurpose("Leisure");
        } else if (businessRBtn.isSelected()) {
            book.setRentpurpose("Business");
        } else if (othersRBtn.isSelected()) {
            book.setRentpurpose("Others");
        } else {
            book.setRentpurpose("");
        }

        book.setRemarks(txtRemarks.getText());

        if (cardRBtn.isSelected()) {
            book.setPaymentMethod("Credit/Debit Card");
        } else if (visaRBtn.isSelected()) {
            book.setPaymentMethod("Visa/Master/Paypal/Alipay");
        } else if (ewalletRBtn.isSelected()) {
            book.setPaymentMethod("E-Wallet");
        } else if (onlineRBtn.isSelected()) {
            book.setPaymentMethod("Online Banking");
        } else if (storeRBtn.isSelected()) {
            book.setPaymentMethod("Convenient Store");
        } else {
            book.setPaymentMethod("");
        }

        book.setPaymentStatus("FULL PAYMENT");
        book.setStatus("APPROVED");
        book.setRentalFee(setTotalRentalFeeLbl.getText());
        book.setPayUponCollection(setPayUponCollection.getText());
        book.setPayOnline(setPayOnlineLbl.getText());

        Boolean dataValid = DataValidation.BookingValidation(book);

        if (!txtEmail.getText().equalsIgnoreCase(txtReEnterEmail.getText())) {
            JOptionPane.showMessageDialog(this, "Your email and re-enter email do not match!\nPlease ensure you entered the correct email.", "Warning!", JOptionPane.WARNING_MESSAGE);
            dataValid = false;
        }

        if (dataValid) {
            StoreData.storeBooking(book);

            Car car = new Car();
            car.setNumberPlate(passNumPlateLbl.getText());
            try {
                String updatedCarlist[] = ModifyCarData.ChangeCarStatus(car, "AVAILABLE", "RENTED");
                UpdateData.UpdateFile(updatedCarlist, "car.txt");

            } catch (FileNotFoundException ex) {
                Logger.getLogger(CustomerBookingPage.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }//GEN-LAST:event_makeBookingBtnActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;

                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AdminBookingPage.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AdminBookingPage.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AdminBookingPage.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AdminBookingPage.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    new AdminBookingPage().setVisible(true);
                } catch (FileNotFoundException ex) {
                    JOptionPane.showMessageDialog(null, ex);
                }
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton backBtn;
    private javax.swing.JLabel bgLbl;
    private javax.swing.JRadioButton businessRBtn;
    private javax.swing.JLabel carLbl;
    private javax.swing.JRadioButton cardRBtn;
    private javax.swing.JButton closeBtn;
    private javax.swing.JLabel customerInfoLbl;
    private javax.swing.JButton deleteBookingBtn;
    private javax.swing.JLabel emailLbl;
    private javax.swing.JRadioButton ewalletRBtn;
    private javax.swing.JLabel icLbl;
    private javax.swing.JRadioButton leisureRBtn;
    private javax.swing.JButton logoutBtn;
    private javax.swing.JButton makeBookingBtn;
    private javax.swing.JLabel nameLbl;
    private javax.swing.JLabel nationalityLbl;
    private javax.swing.JRadioButton onlineRBtn;
    private javax.swing.JRadioButton othersRBtn;
    private javax.swing.JLabel passBookingLbl;
    private javax.swing.JLabel passBrandLbl;
    private javax.swing.JLabel passLbl;
    private javax.swing.JLabel passModelLbl;
    private javax.swing.JLabel passNumPlateLbl;
    private javax.swing.JLabel passPickDtLbl;
    private javax.swing.JLabel passPickTimeLbl;
    private javax.swing.JLabel passReturnDtLbl;
    private javax.swing.JLabel passReturnTimeLbl;
    private javax.swing.JLabel passTypeLbl;
    private javax.swing.JLabel payNowLbl;
    private javax.swing.JLabel payOnlineLbl;
    private javax.swing.JLabel payUponCollectionLbl;
    private javax.swing.JLabel paymentInfoLbl;
    private javax.swing.ButtonGroup paymentMethodBtnGrp;
    private javax.swing.JLabel paymentMethodLbl;
    private javax.swing.JLabel phoneLbl;
    private javax.swing.JLabel pickupDateLbl;
    private javax.swing.JLabel pickupLocationLbl;
    private javax.swing.JLabel reEnterEmailLbl;
    private javax.swing.JLabel remarksLbl;
    private javax.swing.ButtonGroup rentPurposeBtnGrp;
    private javax.swing.JLabel rentPurposeLbl;
    private javax.swing.JLabel rentalInfoLbl;
    private javax.swing.JLabel rentalInforLbl;
    private javax.swing.JButton resetBtn;
    private javax.swing.JLabel returnDateLbl;
    private javax.swing.JComboBox<String> returnLocationComboBox;
    private javax.swing.JLabel returnLocationLbl;
    private javax.swing.JLabel setBrandModelLbl;
    private javax.swing.JLabel setLocationLbl;
    private javax.swing.JLabel setPayNowLbl;
    private javax.swing.JLabel setPayOnlineLbl;
    private javax.swing.JLabel setPayUponCollection;
    private javax.swing.JLabel setPickupDateTimeLbl;
    private javax.swing.JLabel setReturnDateTimeLbl;
    private javax.swing.JLabel setTotalLbl;
    private javax.swing.JLabel setTotalRentalFeeLbl;
    private javax.swing.JRadioButton storeRBtn;
    private javax.swing.JLabel titleLbl;
    private javax.swing.JLabel totalLbl;
    private javax.swing.JLabel totalRentalFeeLbl;
    private javax.swing.JTextField txtEmail;
    private javax.swing.JTextField txtIc;
    private javax.swing.JTextField txtName;
    private javax.swing.JTextField txtNationality;
    private javax.swing.JTextField txtPhone;
    private javax.swing.JTextField txtReEnterEmail;
    private javax.swing.JTextField txtRemarks;
    private javax.swing.JButton updateBookingBtn;
    private javax.swing.JRadioButton visaRBtn;
    // End of variables declaration//GEN-END:variables
}
