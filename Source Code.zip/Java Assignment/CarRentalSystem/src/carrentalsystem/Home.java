
package carrentalsystem;

import javax.swing.JOptionPane;

public class Home extends javax.swing.JFrame {

    public Home() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        topLbl = new javax.swing.JLabel();
        klLbl = new javax.swing.JLabel();
        carRentalLbl = new javax.swing.JLabel();
        premiumLbl = new javax.swing.JLabel();
        youLbl = new javax.swing.JLabel();
        withLbl = new javax.swing.JLabel();
        getStartedBtn = new javax.swing.JButton();
        carLbl = new javax.swing.JLabel();
        logoLbl = new javax.swing.JLabel();
        closeBtn = new javax.swing.JButton();
        whiteLbl = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        topLbl.setFont(new java.awt.Font("Eras Demi ITC", 0, 24)); // NOI18N
        topLbl.setText("Top brands, awesome car prices");
        getContentPane().add(topLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 290, 541, 45));

        klLbl.setFont(new java.awt.Font("Eras Bold ITC", 1, 36)); // NOI18N
        klLbl.setText("in Kuala Lumpur");
        getContentPane().add(klLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 220, 541, 72));

        carRentalLbl.setFont(new java.awt.Font("Eras Bold ITC", 1, 36)); // NOI18N
        carRentalLbl.setText("Car Rental");
        getContentPane().add(carRentalLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 170, 291, 72));

        premiumLbl.setFont(new java.awt.Font("Eras Bold ITC", 1, 36)); // NOI18N
        premiumLbl.setText("Premium");
        getContentPane().add(premiumLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 120, 235, 72));

        youLbl.setFont(new java.awt.Font("Eras Medium ITC", 0, 18)); // NOI18N
        youLbl.setText("you'll find a ride that's right for you at a great price");
        getContentPane().add(youLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 380, -1, 37));

        withLbl.setFont(new java.awt.Font("Eras Medium ITC", 0, 18)); // NOI18N
        withLbl.setText("With so many car brands,");
        getContentPane().add(withLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 340, 307, 45));

        getStartedBtn.setBackground(new java.awt.Color(0, 0, 0));
        getStartedBtn.setFont(new java.awt.Font("Eras Demi ITC", 1, 24)); // NOI18N
        getStartedBtn.setForeground(new java.awt.Color(255, 255, 255));
        getStartedBtn.setText("Get Started");
        getStartedBtn.setBorder(null);
        getStartedBtn.setMaximumSize(new java.awt.Dimension(254, 84));
        getStartedBtn.setMinimumSize(new java.awt.Dimension(254, 84));
        getStartedBtn.setPreferredSize(new java.awt.Dimension(254, 84));
        getStartedBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                getStartedBtnActionPerformed(evt);
            }
        });
        getContentPane().add(getStartedBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 440, 200, 70));

        carLbl.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/HomeCar.png"))); // NOI18N
        getContentPane().add(carLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 110, 621, 433));

        logoLbl.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        logoLbl.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/logos.png"))); // NOI18N
        getContentPane().add(logoLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 590, 1274, -1));

        closeBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/close.png"))); // NOI18N
        closeBtn.setBorderPainted(false);
        closeBtn.setContentAreaFilled(false);
        closeBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                closeBtnActionPerformed(evt);
            }
        });
        getContentPane().add(closeBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(1180, 30, -1, -1));

        whiteLbl.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/HomeWhite.png"))); // NOI18N
        getContentPane().add(whiteLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void getStartedBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_getStartedBtnActionPerformed
        setVisible(false);
        new SelectUserType().setVisible(true);
    }//GEN-LAST:event_getStartedBtnActionPerformed

    private void closeBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_closeBtnActionPerformed
        int confirmClose = JOptionPane.showConfirmDialog(null, "Do you really want to exit Premium Car Rental System ?", "Please Select", JOptionPane.YES_NO_OPTION);
        if (confirmClose == 0) {
            System.exit(0);
        }       
    }//GEN-LAST:event_closeBtnActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Home.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Home.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Home.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Home.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Home().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel carLbl;
    private javax.swing.JLabel carRentalLbl;
    private javax.swing.JButton closeBtn;
    private javax.swing.JButton getStartedBtn;
    private javax.swing.JLabel klLbl;
    private javax.swing.JLabel logoLbl;
    private javax.swing.JLabel premiumLbl;
    private javax.swing.JLabel topLbl;
    private javax.swing.JLabel whiteLbl;
    private javax.swing.JLabel withLbl;
    private javax.swing.JLabel youLbl;
    // End of variables declaration//GEN-END:variables
}
